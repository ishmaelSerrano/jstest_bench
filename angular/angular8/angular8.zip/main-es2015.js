(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./$$_lazy_route_resource lazy recursive":
/*!******************************************************!*\
  !*** ./$$_lazy_route_resource lazy namespace object ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html":
/*!**************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n\n<div id=\"app\" class=\"container\">\n  <nav class=\"navbar\">\n    <div class=\"nav_icon\" onclick=\"toggleSidebar()\">\n      <i class=\"fa fa-bars\" aria-hidden=\"true\"></i>\n    </div>\n  </nav>\n\n  <main>\n    <div class=\"main__container\">\n      <!-- MAIN TITLE STARTS HERE -->\n\n      <router-outlet></router-outlet>\n\n    </div>\n  </main>\n\n  <div id=\"sidebar\">\n\n    <div class=\"sidebar__img\">\n      <img src=\"/assets/avatar.png\" alt=\"Angular 8\" style=\"width: 100% !important;\" />\n    </div>\n    <div class=\"sidebar__menu\">\n\n      <h2>Rules\n        <div *ngFor=\"let route of rules;\" class=\"sidebar__link\">\n          <i class=\"fa fa-user-secret\" aria-hidden=\"true\"></i>\n          <a [routerLink]=\"route.path\" routerLinkActive=\"active\">{{route.title}}</a>\n        </div>\n\n      </h2>\n\n      <h2><a routerLink=\"/sources\" routerLinkActive=\"active\">\n        Sources\n      </a></h2>\n\n\n    </div>\n  </div>\n</div>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/rules/cookiemanipulation/cookiemanipulation.component.html":
/*!******************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/rules/cookiemanipulation/cookiemanipulation.component.html ***!
  \******************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"main__container\">\n  <h3>Cookie Manipulation</h3>\n  <b>About Cookie Manipulation</b>\n\n  <p>Some DOM-based vulnerabilities allow attackers to manipulate data that they do not typically control. This transforms normally-safe data types, such as cookies, into potential sources. DOM-based cookie-manipulation vulnerabilities arise when a script writes attacker-controllable data into the value of a cookie.</p>\n\n  <p>An attacker may be able to use this vulnerability to construct a URL that, if visited by another user, will set an arbitrary value in the user's cookie. Many sinks are largely harmless on their own, but DOM-based cookie-manipulation attacks demonstrate how low-severity vulnerabilities can sometimes be used as part of an exploit chain for a high-severity attack. For example, if JavaScript writes data from a source into document.cookie without sanitizing it first, an attacker can manipulate the value of a single cookie to inject arbitrary values.</p>\n\n  <b>Resources:</b>\n  <div>\n    <ul>\n      <li><a href=\"https://owasp.org/www-project-web-security-testing-guide/latest/4-Web_Application_Security_Testing/06-Session_Management_Testing/02-Testing_for_Cookies_Attributes\" target=\"_blank\">OWASP Testing for Cookies Attributes</a></li>\n      <li><a href=\"https://portswigger.net/web-security/dom-based/cookie-manipulation\" target=\"_blank\">PortSwigger DOM based cookie manipulation</a></li>\n          <li><a href=\"https://cwe.mitre.org/data/definitions/565.html\" target=\"_blank\">CWE-565: Reliance on Cookies without Validation and Integrity Checking</a></li>\n    </ul>\n  </div>\n\n  <div *ngIf=\"cookies\">\n    <div class=\"card\">\n      <i class=\"fa fa-user-o fa-2x text-lightblue\" aria-hidden=\"true\"></i>\n      <!-- <div class=\"card_inner\"> -->\n        <p class=\"text-primary-p\">Welcome back {{ cookies['userName'] }}</p>\n        <!-- <span class=\"font-bold text-title\">578</span> -->\n      <!-- </div> -->\n    </div>\n  </div>\n\n  <ul ngbNav #nav=\"ngbNav\" [(activeId)]=\"activeIdString\" class=\"nav-tabs\">\n    <li [ngbNavItem]=\"'tab1'\">\n      <a ngbNavLink>Sinks</a>\n      <ng-template ngbNavContent>\n        <pre>\n  vulnerability cookie-manipulation: &lt;dom::Document>.cookie [~sanitized]\n        </pre>\n      </ng-template>\n    </li>\n\n    <li [ngbNavItem]=\"'tab2'\">\n      <a ngbNavLink>URL Sources</a>\n      <ng-template ngbNavContent>\n        <div class=\"sink\">\n          <p>One possible attack vector is when a site loads a url query param into a cookie such as a username.</p>\n          <button (click)=\"loadHash()\">Click here to load the URL query param 'userName' into a cookie named userName sink.</button>\n        </div>\n      </ng-template>\n    </li>\n\n    <li [ngbNavItem]=\"'tab3'\">\n      <a ngbNavLink>Window/Document Sources</a>\n      <ng-template ngbNavContent>\n        <div class=\"sink\">\n          <h5>Text Input:</h5>\n          <form (submit)=\"loadInput(dangerousCookieInput.value)\">\n            <input type=\"text\" #dangerousCookieInput>\n            <input type=\"submit\" value=\"Submit\">\n          </form>\n        </div>\n      </ng-template>\n    </li>\n\n    <!-- <li [ngbNavItem]=\"'tab4'\">\n        <a ngbNavLink>Communication Sources</a>\n        <ng-template ngbNavContent>\n          <div class=\"sink\">\n            <button (click)=\"checkForCookie()\">Click here to load cookie named 'username' into a  sink.</button>\n          </div>\n        </ng-template>\n      </li> -->\n\n  </ul>\n  <div [ngbNavOutlet]=\"nav\" class=\"mt-2\"></div>\n</div>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/rules/domainmanipulation/domainmanipulation.component.html":
/*!******************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/rules/domainmanipulation/domainmanipulation.component.html ***!
  \******************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<app-rule [rule]=\"rule\"></app-rule>\n\n<p>* Note: Many current browsers have built in protections against this vulnerablity, so when using the below examples they may not work or result in an error in the console. *</p>\n\n<ul ngbNav #nav=\"ngbNav\" [(activeId)]=\"activeIdString\" class=\"nav-tabs\">\n  <li [ngbNavItem]=\"'tab1'\">\n    <a ngbNavLink>Sinks</a>\n    <ng-template ngbNavContent>\n      <pre>\n{{ rule.sinks }}\n      </pre>\n    </ng-template>\n  </li>\n\n  <li [ngbNavItem]=\"'tab2'\">\n    <a ngbNavLink>URL Sources</a>\n    <ng-template ngbNavContent>\n      <div class=\"sink\">\n        <button (click)=\"loadHash()\">Click here to load the URL hash into the document domain.</button>\n      </div>\n    </ng-template>\n  </li>\n\n  <li [ngbNavItem]=\"'tab3'\">\n    <a ngbNavLink>Window/Document Sources</a>\n    <ng-template ngbNavContent>\n      <div class=\"sink\">\n        <h5>Text Input:</h5>\n        <form (submit)=\"loadInput(dangerousCookieInput.value)\">\n          <input type=\"text\" #dangerousCookieInput>\n          <input type=\"submit\" value=\"Submit\">\n        </form>\n      </div>\n    </ng-template>\n  </li>\n\n  <li [ngbNavItem]=\"'tab4'\">\n      <a ngbNavLink>Communication Sources</a>\n      <ng-template ngbNavContent>\n        <div class=\"sink\">\n          <button (click)=\"checkForCookie()\">Click here to load cookie named 'redirect' into the document domain.</button>\n        </div>\n      </ng-template>\n    </li>\n\n</ul>\n<div [ngbNavOutlet]=\"nav\" class=\"mt-2\"></div>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/rules/html5-storage-manipulation/html5-storage-manipulation.component.html":
/*!**********************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/rules/html5-storage-manipulation/html5-storage-manipulation.component.html ***!
  \**********************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<app-rule [rule]=\"rule\"></app-rule>\n\n<p id=\"vulnerableContent\">This content is vulnerable</p>\n\n<ul ngbNav #nav=\"ngbNav\" [(activeId)]=\"activeIdString\" class=\"nav-tabs\">\n  <li [ngbNavItem]=\"'tab1'\">\n    <a ngbNavLink>Sinks</a>\n    <ng-template ngbNavContent>\n      <pre>\n{{ rule.sinks }}\n      </pre>\n    </ng-template>\n  </li>\n\n  <li [ngbNavItem]=\"'tab2'\">\n    <a ngbNavLink>URL Sources</a>\n    <ng-template ngbNavContent>\n      <div class=\"sink\">\n        <button (click)=\"loadHash()\">Click here to load URL param 'localStorage' and save it as a storage value called 'userName'.</button>\n      </div>\n    </ng-template>\n  </li>\n\n  <li [ngbNavItem]=\"'tab3'\">\n    <a ngbNavLink>Window/Document Sources</a>\n    <ng-template ngbNavContent>\n      <div class=\"sink\">\n        <h5>Text Input:</h5>\n        <form (submit)=\"loadInput(dangerousCookieInput.value)\">\n          <input type=\"text\" #dangerousCookieInput>\n          <input type=\"submit\" value=\"Submit\">\n        </form>\n      </div>\n    </ng-template>\n  </li>\n\n  <!-- <li [ngbNavItem]=\"'tab4'\">\n      <a ngbNavLink>Communication Sources</a>\n      <ng-template ngbNavContent>\n      <div class=\"sink\">\n        <button (click)=\"checkForCookie()\">Click here to load cookie named 'webMessage' and send to the page as a web message.</button>\n      </div>\n    </ng-template>\n  </li> -->\n\n</ul>\n<div [ngbNavOutlet]=\"nav\" class=\"mt-2\"></div>\n\n<div class=\"sink\">\n  <button (click)=\"loadLocalStorage()\">Click here to load local storage value 'userName' set above and write it to the page.</button>\n</div>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/rules/jsinjection/jsinjection.component.html":
/*!****************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/rules/jsinjection/jsinjection.component.html ***!
  \****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<h3>JS Injection</h3>\n<b>About JS Injection</b>\n\n<p>DOM-based JavaScript-injection vulnerabilities arise when a script executes attacker-controllable data as JavaScript. An attacker may be able to use the vulnerability to construct a URL that, if visited by another user, will cause arbitrary JavaScript supplied by the attacker to execute in the context of the user's browser session.</p>\n\n<b>Resources:</b>\n<div>\n  <ul>\n    <li><a href=\"https://owasp.org/www-project-web-security-testing-guide/latest/4-Web_Application_Security_Testing/11-Client-side_Testing/02-Testing_for_JavaScript_Execution\" target=\"_blank\">OWASP Testing for JavaScript Execution</a></li>\n    <li><a href=\"https://portswigger.net/web-security/dom-based/javascript-injection\" target=\"_blank\">PortSwigger DOM\n        Based JavaScript Injection</a></li>\n        <li><a href=\"https://cwe.mitre.org/data/definitions/94.html\" target=\"_blank\">CWE-94: Improper Control of Generation of Code ('Code Injection')\n        </a></li>\n        <li><a href=\"https://cwe.mitre.org/data/definitions/74.html\" target=\"_blank\">CWE-74: Improper Neutralization of Special Elements in Output Used by a Downstream Component ('Injection')\n        </a></li>\n  </ul>\n</div>\n\n\n\n\n<ul ngbNav #nav=\"ngbNav\" [(activeId)]=\"activeIdString\" class=\"nav-tabs\">\n  <li [ngbNavItem]=\"'tab1'\">\n    <a ngbNavLink>Sinks</a>\n    <ng-template ngbNavContent>\n      <pre>\nvulnerability js-injection: eval(*)                                            [~sanitized]\nvulnerability js-injection: &lt;stdlib::FunctionConstructor>(*)                   [~sanitized]\nvulnerability js-injection: new &lt;stdlib::FunctionConstructor>(*)               [~sanitized]\nvulnerability js-injection: &lt;dom::WindowOrWorkerGlobalScope>.setTimeout(*)     [~sanitized]\nvulnerability js-injection: setTimeout(*)                                      [~sanitized]\nvulnerability js-injection: &lt;dom::WindowOrWorkerGlobalScope>.setInterval(*)    [~sanitized]\nvulnerability js-injection: setInterval(*)                                     [~sanitized]\nvulnerability js-injection: &lt;dom::WindowOrWorkerGlobalScope>.setImmediate(*)   [~sanitized]\nvulnerability js-injection: setImmediate(*)                                    [~sanitized]\nvulnerability js-injection: &lt;dom::WindowOrWorkerGlobalScope>.msSetImmediate(*) [~sanitized]\nvulnerability js-injection: &lt;dom::Document>.execCommand(*)                     [~sanitized]\nvulnerability js-injection: &lt;dom::WindowOrWorkerGlobalScope>.execScript(*)     [~sanitized] // only defined in IE\nvulnerability js-injection: &lt;dom::Range>.createContextualFragment(*)           [~sanitized]\nvulnerability js-injection: &lt;dom::crypto>.generateCRMFRequest(*)               [~sanitized]\n      </pre>\n    </ng-template>\n  </li>\n\n  <li [ngbNavItem]=\"'tab2'\">\n    <a ngbNavLink>URL Sources</a>\n    <ng-template ngbNavContent>\n      <div class=\"sink\">\n        <button (click)=\"loadHash()\">Click here to load the URL hash into a JS eval sink.</button>\n      </div>\n    </ng-template>\n  </li>\n\n  <li [ngbNavItem]=\"'tab3'\">\n    <a ngbNavLink>Window/Document Sources</a>\n    <ng-template ngbNavContent>\n      <div class=\"sink\">\n        <h5>Text Input:</h5>\n        <form (submit)=\"loadInput(dangerousCookieInput.value)\">\n          <input type=\"text\" #dangerousCookieInput>\n          <input type=\"submit\" value=\"Submit\">\n        </form>\n      </div>\n    </ng-template>\n  </li>\n\n  <li [ngbNavItem]=\"'tab4'\">\n      <a ngbNavLink>Communication Sources</a>\n      <ng-template ngbNavContent>\n      <div class=\"sink\">\n        <button (click)=\"checkForCookie()\">Click here to load cookie named 'username' into a JS eval sink.</button>\n      </div>\n    </ng-template>\n  </li>\n\n</ul>\n<div [ngbNavOutlet]=\"nav\" class=\"mt-2\"></div>\n\n\n\n\n\n\n\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/rules/json-injection/json-injection.component.html":
/*!**********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/rules/json-injection/json-injection.component.html ***!
  \**********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<app-rule [rule]=\"rule\"></app-rule>\n\n<p id=\"vulnerableId\">This content is vulnerable.</p>\n\n<ul ngbNav #nav=\"ngbNav\" [(activeId)]=\"activeIdString\" class=\"nav-tabs\">\n  <li [ngbNavItem]=\"'tab1'\">\n    <a ngbNavLink>Sinks</a>\n    <ng-template ngbNavContent>\n      <pre>\n{{ rule.sinks }}\n      </pre>\n    </ng-template>\n  </li>\n\n  <li [ngbNavItem]=\"'tab2'\">\n    <a ngbNavLink>URL Sources</a>\n    <ng-template ngbNavContent>\n      <div class=\"sink\">\n        <button (click)=\"loadHash()\">Click here to load URL param 'json' and have the page render it.</button>\n      </div>\n    </ng-template>\n  </li>\n\n  <li [ngbNavItem]=\"'tab3'\">\n    <a ngbNavLink>Window/Document Sources</a>\n    <ng-template ngbNavContent>\n      <div class=\"sink\">\n        <h5>Text Input:</h5>\n        <form (submit)=\"loadInput(dangerousCookieInput.value)\">\n          <input type=\"text\" #dangerousCookieInput>\n          <input type=\"submit\" value=\"Submit\">\n        </form>\n      </div>\n    </ng-template>\n  </li>\n\n  <li [ngbNavItem]=\"'tab4'\">\n      <a ngbNavLink>Communication Sources</a>\n      <ng-template ngbNavContent>\n      <div class=\"sink\">\n        <button (click)=\"checkForCookie()\">Click here to load cookie named 'json' and have the page render it.</button>\n      </div>\n    </ng-template>\n  </li>\n\n</ul>\n<div [ngbNavOutlet]=\"nav\" class=\"mt-2\"></div>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/rules/link-manipulation/link-manipulation.component.html":
/*!****************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/rules/link-manipulation/link-manipulation.component.html ***!
  \****************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<app-rule [rule]=\"rule\"></app-rule>\n\n<p>The following link is vulnerable: <a id=\"vulnerableLink\" href=\"https://www.google.com\">Vulnerable Link.</a></p>\n\n<ul ngbNav #nav=\"ngbNav\" [(activeId)]=\"activeIdString\" class=\"nav-tabs\">\n  <li [ngbNavItem]=\"'tab1'\">\n    <a ngbNavLink>Sinks</a>\n    <ng-template ngbNavContent>\n      <pre>\n{{ rule.sinks }}\n      </pre>\n    </ng-template>\n  </li>\n\n  <li [ngbNavItem]=\"'tab2'\">\n    <a ngbNavLink>URL Sources</a>\n    <ng-template ngbNavContent>\n      <div class=\"sink\">\n        <button (click)=\"loadHash()\">Click here to load the URL hash into the above vulnerable link.</button>\n      </div>\n    </ng-template>\n  </li>\n\n  <li [ngbNavItem]=\"'tab3'\">\n    <a ngbNavLink>Window/Document Sources</a>\n    <ng-template ngbNavContent>\n      <div class=\"sink\">\n        <h5>Text Input:</h5>\n        <p>Insert a malicious value to insert into the above vulnerable link.</p>\n        <form (submit)=\"loadInput(dangerousCookieInput.value)\">\n          <input type=\"text\" #dangerousCookieInput>\n          <input type=\"submit\" value=\"Submit\">\n        </form>\n      </div>\n    </ng-template>\n  </li>\n\n  <li [ngbNavItem]=\"'tab4'\">\n      <a ngbNavLink>Communication Sources</a>\n      <ng-template ngbNavContent>\n      <div class=\"sink\">\n        <button (click)=\"checkForCookie()\">Click here to load cookie named 'manipulatedLink' into the above vulnerable link.</button>\n      </div>\n    </ng-template>\n  </li>\n\n</ul>\n<div [ngbNavOutlet]=\"nav\" class=\"mt-2\"></div>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/rules/local-file-path-manipulation/local-file-path-manipulation.component.html":
/*!**************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/rules/local-file-path-manipulation/local-file-path-manipulation.component.html ***!
  \**************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<app-rule [rule]=\"rule\"></app-rule>\n\n<!-- <input type=\"file\" (onchange)=\"readFiles(event)\" > -->\n\n<p>More research being done into how this can be properly implemented</p>\n\n\n<ul ngbNav #nav=\"ngbNav\" [(activeId)]=\"activeIdString\" class=\"nav-tabs\">\n  <li [ngbNavItem]=\"'tab1'\">\n    <a ngbNavLink>Sinks</a>\n    <ng-template ngbNavContent>\n      <pre>\n{{ rule.sinks }}\n      </pre>\n    </ng-template>\n  </li>\n\n  <li [ngbNavItem]=\"'tab2'\">\n    <a ngbNavLink>URL Sources</a>\n    <ng-template ngbNavContent>\n      <div class=\"sink\">\n        <button (click)=\"loadHash()\">Click here to load URL param 'webMessage' and send as a web message.</button>\n      </div>\n    </ng-template>\n  </li>\n\n  <li [ngbNavItem]=\"'tab3'\">\n    <a ngbNavLink>Window/Document Sources</a>\n    <ng-template ngbNavContent>\n      <div class=\"sink\">\n        <h5>Text Input:</h5>\n        <form (submit)=\"loadInput(dangerousCookieInput.value)\">\n          <input type=\"text\" #dangerousCookieInput>\n          <input type=\"submit\" value=\"Submit\">\n        </form>\n      </div>\n    </ng-template>\n  </li>\n\n  <li [ngbNavItem]=\"'tab4'\">\n      <a ngbNavLink>Communication Sources</a>\n      <ng-template ngbNavContent>\n      <div class=\"sink\">\n        <button (click)=\"checkForCookie()\">Click here to load cookie named 'webMessage' and send to the page as a web message.</button>\n      </div>\n    </ng-template>\n  </li>\n\n</ul>\n<div [ngbNavOutlet]=\"nav\" class=\"mt-2\"></div>\n\n\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/rules/open-redirection/open-redirection.component.html":
/*!**************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/rules/open-redirection/open-redirection.component.html ***!
  \**************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<app-rule [rule]=\"rule\"></app-rule>\n\n<ul ngbNav #nav=\"ngbNav\" [(activeId)]=\"activeIdString\" class=\"nav-tabs\">\n  <li [ngbNavItem]=\"'tab1'\">\n    <a ngbNavLink>Sinks</a>\n    <ng-template ngbNavContent>\n      <pre>\n{{ rule.sinks }}\n      </pre>\n    </ng-template>\n  </li>\n\n  <li [ngbNavItem]=\"'tab2'\">\n    <a ngbNavLink>URL Sources</a>\n    <ng-template ngbNavContent>\n      <div class=\"sink\">\n        <button (click)=\"loadHash()\">Click here to load the URL hash into a JS eval sink.</button>\n      </div>\n    </ng-template>\n  </li>\n\n  <li [ngbNavItem]=\"'tab3'\">\n    <a ngbNavLink>Window/Document Sources</a>\n    <ng-template ngbNavContent>\n      <div class=\"sink\">\n        <h5>Text Input:</h5>\n        <form (submit)=\"loadInput(dangerousCookieInput.value)\">\n          <input type=\"text\" #dangerousCookieInput>\n          <input type=\"submit\" value=\"Submit\">\n        </form>\n      </div>\n    </ng-template>\n  </li>\n\n  <li [ngbNavItem]=\"'tab4'\">\n      <a ngbNavLink>Communication Sources</a>\n      <ng-template ngbNavContent>\n      <div class=\"sink\">\n        <button (click)=\"checkForCookie()\">Click here to load cookie named 'username' into a  sink.</button>\n      </div>\n    </ng-template>\n  </li>\n\n</ul>\n<div [ngbNavOutlet]=\"nav\" class=\"mt-2\"></div>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/rules/request-header-manipulation/request-header-manipulation.component.html":
/*!************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/rules/request-header-manipulation/request-header-manipulation.component.html ***!
  \************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<app-rule [rule]=\"rule\"></app-rule>\n\n<ul ngbNav #nav=\"ngbNav\" [(activeId)]=\"activeIdString\" class=\"nav-tabs\">\n  <li [ngbNavItem]=\"'tab1'\">\n    <a ngbNavLink>Sinks</a>\n    <ng-template ngbNavContent>\n      <pre>\n{{ rule.sinks }}\n      </pre>\n    </ng-template>\n  </li>\n\n  <li [ngbNavItem]=\"'tab2'\">\n    <a ngbNavLink>URL Sources</a>\n    <ng-template ngbNavContent>\n      <div class=\"sink\">\n        <button (click)=\"loadHash()\">Click here to load the URL hash into a request header while making a request(viewable in network tab).</button>\n      </div>\n    </ng-template>\n  </li>\n\n  <li [ngbNavItem]=\"'tab3'\">\n    <a ngbNavLink>Window/Document Sources</a>\n    <ng-template ngbNavContent>\n      <div class=\"sink\">\n        <h5>Text Input:</h5>\n        <p>Insert a malicious value to insert into a request header while making a request(viewable in network tab).</p>\n        <form (submit)=\"loadInput(dangerousCookieInput.value)\">\n          <input type=\"text\" #dangerousCookieInput>\n          <input type=\"submit\" value=\"Submit\">\n        </form>\n      </div>\n    </ng-template>\n  </li>\n\n  <li [ngbNavItem]=\"'tab4'\">\n      <a ngbNavLink>Communication Sources</a>\n      <ng-template ngbNavContent>\n      <div class=\"sink\">\n        <button (click)=\"checkForCookie()\">Click here to load cookie named 'badHeader' into a request header while making a request(viewable in network tab).</button>\n      </div>\n    </ng-template>\n  </li>\n\n</ul>\n<div [ngbNavOutlet]=\"nav\" class=\"mt-2\"></div>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/rules/web-message-manipulation/web-message-manipulation.component.html":
/*!******************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/rules/web-message-manipulation/web-message-manipulation.component.html ***!
  \******************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<app-rule [rule]=\"rule\"></app-rule>\n\n<p id=\"vulnerableId\">This content is vulnerable to a web message attack.</p>\n\n<ul ngbNav #nav=\"ngbNav\" [(activeId)]=\"activeIdString\" class=\"nav-tabs\">\n  <li [ngbNavItem]=\"'tab1'\">\n    <a ngbNavLink>Sinks</a>\n    <ng-template ngbNavContent>\n      <pre>\n{{ rule.sinks }}\n      </pre>\n    </ng-template>\n  </li>\n\n  <li [ngbNavItem]=\"'tab2'\">\n    <a ngbNavLink>URL Sources</a>\n    <ng-template ngbNavContent>\n      <div class=\"sink\">\n        <button (click)=\"loadHash()\">Click here to load URL param 'webMessage' and send as a web message.</button>\n      </div>\n    </ng-template>\n  </li>\n\n  <li [ngbNavItem]=\"'tab3'\">\n    <a ngbNavLink>Window/Document Sources</a>\n    <ng-template ngbNavContent>\n      <div class=\"sink\">\n        <h5>Text Input:</h5>\n        <form (submit)=\"loadInput(dangerousCookieInput.value)\">\n          <input type=\"text\" #dangerousCookieInput>\n          <input type=\"submit\" value=\"Submit\">\n        </form>\n      </div>\n    </ng-template>\n  </li>\n\n  <li [ngbNavItem]=\"'tab4'\">\n      <a ngbNavLink>Communication Sources</a>\n      <ng-template ngbNavContent>\n      <div class=\"sink\">\n        <button (click)=\"checkForCookie()\">Click here to load cookie named 'webMessage' and send to the page as a web message.</button>\n      </div>\n    </ng-template>\n  </li>\n\n</ul>\n<div [ngbNavOutlet]=\"nav\" class=\"mt-2\"></div>\n\n\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/rules/xss/xss.component.html":
/*!************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/rules/xss/xss.component.html ***!
  \************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"main__container\">\n  <div class=\"main__title\">\n    <img src=\"assets/hello.svg\" alt=\"\">\n    <div class=\"main__greeting\">\n      <h1>DOM Based XSS course</h1>\n      <p>Learn different sinks and sources that may result to DOM XSS</p>\n    </div>\n  </div>\n  <br>\n  <b>About the course:</b>\n\n  <p>\n    Welcome to this course on DOM based Cross-Site Scripting (XSS)! In this course, we explore one of the biggest risks\n    facing web applications today.\n  </p>\n  <p>\n    DOM-based XSS, also known as Type-0 XSS, is an XSS attack in which the attack payload is executed by altering the\n    DOM\n    in the victim’s browser. This causes the client to run code, without the user’s knowledge or consent. The page\n    itself\n    (i.e. the HTTP response) will not change, but a malicious change in the DOM environment will cause the client code\n    contained in the page to execute in a different way.\n  </p>\n\n  <br>\n  <b>Resources:</b>\n  <div>\n    <ul>\n      <li><a href=\"https://owasp.org/www-community/attacks/DOM_Based_XSS\" target=\"_blank\">OWASP DOM Based XSS</a></li>\n      <li><a href=\"https://portswigger.net/web-security/cross-site-scripting/dom-based\" target=\"_blank\">PortSwigger DOM\n          Based XSS</a></li>\n      <li><a href=\"https://cwe.mitre.org/data/definitions/79.html\" target=\"_blank\">CWE-79: Improper Neutralization of\n          Input During Web Page Generation ('Cross-site Scripting')</a></li>\n    </ul>\n  </div>\n\n  <br>\n\n  <b>Sinks:</b>\n  <ul ngbNav #nav=\"ngbNav\" [(activeId)]=\"activeIdString\" class=\"nav-tabs\">\n    <li [ngbNavItem]=\"'tab1'\">\n      <a ngbNavLink>Document</a>\n      <ng-template ngbNavContent>\n        <div class=\"main__container\">\n\n          <div class=\"main__cards\">\n            <div class=\"card\">\n              <i class=\"fa fa-user-o fa-2x text-lightblue\" aria-hidden=\"true\"></i>\n              <div class=\"card_inner\">\n                <p class=\"text-primary-p\">Number of Subscribers</p>\n                <span class=\"font-bold text-title\">578</span>\n              </div>\n            </div>\n\n            <div class=\"card\">\n              <i class=\"fa fa-calendar fa-2x text-red\" aria-hidden=\"true\"></i>\n              <div class=\"card_inner\">\n                <p class=\"text-primary-p\">Times of Watching</p>\n                <span class=\"font-bold text-title\">2467</span>\n              </div>\n            </div>\n\n            <div class=\"card\">\n              <i class=\"fa fa-video-camera fa-2x text-yellow\" aria-hidden=\"true\"></i>\n              <div class=\"card_inner\">\n                <p class=\"text-primary-p\">Number of Videos</p>\n                <span class=\"font-bold text-title\">340</span>\n              </div>\n            </div>\n\n            <div class=\"card\">\n              <i class=\"fa fa-thumbs-up fa-2x text-green\" aria-hidden=\"true\"></i>\n              <div class=\"card_inner\">\n                <p class=\"text-primary-p\">Number of Likes</p>\n                <span class=\"font-bold text-title\">645</span>\n              </div>\n            </div>\n          </div>\n\n\n          <!-- Default horizontal form -->\n          <form class=\"form-horizontal\">\n            <div class=\"form-group\">\n              <label for=\"id\">Search subscriber</label>\n              <input type=\"text\" class=\"form-control\" aria-describedby=\"idHelp\"\n                     placeholder=\"Enter name\" #subscriberNameInput>\n              <small class=\"form-text text-muted\">Enter subscriber's name</small>\n\n\n            </div>\n          </form>\n          <button class=\"btn btn-primary\" (click)=\"searchForSubscriber()\">Search</button>\n\n          <div id=\"searchQuery\" class=\"hidden\">Search query:</div>\n          <!-- Default horizontal form -->\n\n\n        </div>\n      </ng-template>\n    </li>\n    <li [ngbNavItem]=\"'tab2'\">\n      <a ngbNavLink>HTMLElement</a>\n      <ng-template ngbNavContent>\n        <div class=\"main__container\">\n\n          <div class=\"charts\">\n            <div class=\"charts__left\">\n              <form class=\"form-horizontal\">\n                <div class=\"form-group\">\n                  <label for=\"income\">Calculate your taxes:</label>\n                  <input type=\"text\" name=\"income\" class=\"form-control\" id=\"income\" aria-describedby=\"idHelp\"\n                         placeholder=\"Enter income\" #incomeInput>\n                  <small class=\"form-text text-muted\">Enter your income</small>\n\n\n                </div>\n              </form>\n              <button class=\"btn btn-primary\" (click)=\"calculateIncomeAndTaxes()\">Calculate</button>\n              <div id=\"incomeValue\" class=\"hidden\">Your income:</div>\n            </div>\n\n            <div class=\"charts__right\">\n              <div class=\"charts__right__title\">\n                <div>\n                  <h1>Income and Txes Reports</h1>\n                </div>\n                <i class=\"fa fa-usd\" aria-hidden=\"true\"></i>\n              </div>\n\n              <div class=\"charts__right__cards\">\n                <div class=\"card1\">\n                  <h1>Income</h1>\n                  <p #incomeValueOutput [innerHTML]=\"getIncome()\"></p>\n                </div>\n\n                <div class=\"card2\">\n                  <h1>Taxes</h1>\n                  <p #taxesValueOutput [innerHTML]=\"getTaxes()\">$124,200</p>\n                </div>\n\n              </div>\n            </div>\n          </div>\n\n\n        </div>\n      </ng-template>\n    </li>\n    <li [ngbNavItem]=\"'tab3'\">\n      <a ngbNavLink>ScriptElement</a>\n      <ng-template ngbNavContent>\n        <p>This is Email Setting</p>\n      </ng-template>\n    </li>\n    <li [ngbNavItem]=\"'tab4'\">\n      <a ngbNavLink>Disabled</a>\n      <ng-template ngbNavContent>\n        <p>This is disabled.</p>\n        <div>\n          <label for=\"username\">Search for name: </label>\n          <input id=\"username\" [value]=\"username\" placeholder=\"Name\">\n          <button (click)=\"searchForName()\">Search </button>\n\n          <span id=\"searchQuery\"></span>\n\n          <a class=\"btn\" [href]=\"theoreticallySafeUrl\">Click</a>\n\n          <h3>DOM XSS, CWE-79, SEC-2161</h3>\n          <h4>Sinks:</h4>\n          <div class=\"sink\">\n            <h5>Text Input:</h5>\n            <form (submit)=\"loadInput(unsanitizedInput.value)\">\n              <textarea #unsanitizedInput></textarea>\n              <input type=\"submit\" value=\"Submit\">\n            </form>\n          </div>\n\n          <div class=\"sink\">\n            <h5>URL Hash:</h5>\n            <button (click)=\"loadHash()\">Submit URL hash for XSS</button>\n          </div>\n\n          <select name=\"dom-xss\">\n            <option value=\"1\">English</option>\n            <option value=\"2\">{{ hashValue }}</option>\n          </select>\n        </div>\n      </ng-template>\n    </li>\n  </ul>\n\n  <div [ngbNavOutlet]=\"nav\" class=\"mt-2\"></div>\n</div>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/sources/communication/document-cookie/document-cookie.component.html":
/*!****************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/sources/communication/document-cookie/document-cookie.component.html ***!
  \****************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<p>document-cookie works!</p>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/sources/communication/message-event-data/message-event-data.component.html":
/*!**********************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/sources/communication/message-event-data/message-event-data.component.html ***!
  \**********************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<p>message-event-data works!</p>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/sources/sources.component.html":
/*!**************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/sources/sources.component.html ***!
  \**************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<h2>Sources</h2>\nThese vulnerabilities source the payload from a component of the address bar, usually the fragment, and use javascript sinks to trigger DOM based XSS.\n\n<h5>Url Based Sources</h5>\n<div *ngFor=\"let source of urlSources;\">\n  <a [routerLink]=\"source.path\" routerLinkActive=\"active\">{{source.title}}</a>\n</div>\n\n<h5>Window / Document Sources</h5>\n<div *ngFor=\"let source of windowDocumentSources;\">\n  <a [routerLink]=\"source.path\" routerLinkActive=\"active\">{{source.title}}</a>\n</div>\n\n<h5>Communication Sources</h5>\n<div *ngFor=\"let source of communicationSources;\">\n  <a [routerLink]=\"source.path\" routerLinkActive=\"active\">{{source.title}}</a>\n</div>\n\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/sources/url/document-base-uri/document-base-uri.component.html":
/*!**********************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/sources/url/document-base-uri/document-base-uri.component.html ***!
  \**********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<p>document-base-uri works!</p>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/sources/url/document-url/document-url.component.html":
/*!************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/sources/url/document-url/document-url.component.html ***!
  \************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<p>document-url works!</p>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/sources/url/location-document-uri/location-document-uri.component.html":
/*!******************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/sources/url/location-document-uri/location-document-uri.component.html ***!
  \******************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<p>location-document-uri works!</p>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/sources/url/location-hash/location-hash.component.html":
/*!**************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/sources/url/location-hash/location-hash.component.html ***!
  \**************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<p>location-hash works!</p>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/sources/url/location-host/location-host.component.html":
/*!**************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/sources/url/location-host/location-host.component.html ***!
  \**************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<p>location-host works!</p>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/sources/url/location-hostname/location-hostname.component.html":
/*!**********************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/sources/url/location-hostname/location-hostname.component.html ***!
  \**********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<p>location-hostname works!</p>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/sources/url/location-href/location-href.component.html":
/*!**************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/sources/url/location-href/location-href.component.html ***!
  \**************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<p>location-href works!</p>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/sources/url/location-origin/location-origin.component.html":
/*!******************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/sources/url/location-origin/location-origin.component.html ***!
  \******************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<p>location-origin works!</p>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/sources/url/location-pathname/location-pathname.component.html":
/*!**********************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/sources/url/location-pathname/location-pathname.component.html ***!
  \**********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<p>location-pathname works!</p>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/sources/url/location-search/location-search.component.html":
/*!******************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/sources/url/location-search/location-search.component.html ***!
  \******************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<p>location-search works!</p>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/sources/url/location-url/location-url.component.html":
/*!************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/sources/url/location-url/location-url.component.html ***!
  \************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<p>location-url works!</p>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/sources/url/window-location/window-location.component.html":
/*!******************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/sources/url/window-location/window-location.component.html ***!
  \******************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<p>window-location works!</p>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/sources/window-document/document-referrer/document-referrer.component.html":
/*!**********************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/sources/window-document/document-referrer/document-referrer.component.html ***!
  \**********************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<p>document-referrer works!</p>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/sources/window-document/element-value/element-value.component.html":
/*!**************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/sources/window-document/element-value/element-value.component.html ***!
  \**************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<p>element-value works!</p>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/sources/window-document/storage-getitem/storage-getitem.component.html":
/*!******************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/sources/window-document/storage-getitem/storage-getitem.component.html ***!
  \******************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<p>storage-getitem works!</p>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/sources/window-document/window-frame-element/window-frame-element.component.html":
/*!****************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/sources/window-document/window-frame-element/window-frame-element.component.html ***!
  \****************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<p>window-frame-element works!</p>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/sources/window-document/window-frames/window-frames.component.html":
/*!**************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/sources/window-document/window-frames/window-frames.component.html ***!
  \**************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<p>window-frames works!</p>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/sources/window-document/window-name/window-name.component.html":
/*!**********************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/sources/window-document/window-name/window-name.component.html ***!
  \**********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<p>window-name works!</p>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/sources/window-document/window-prompt/window-prompt.component.html":
/*!**************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/sources/window-document/window-prompt/window-prompt.component.html ***!
  \**************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<p>window-prompt works!</p>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/templates/rule/rule.component.html":
/*!******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/templates/rule/rule.component.html ***!
  \******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n<h3>{{ rule.name }}</h3>\n<b>About {{ rule.name }}</b>\n\n<p>{{ rule.description }}</p>\n\n<b>Resources:</b>\n<div>\n  <ul>\n    <li><a href=\"{{ rule.OWASP_Link }}\" target=\"_blank\">{{ rule.OWASP_Title }}</a></li>\n    <li><a href=\"{{ rule.PortSwigger_Link }}\" target=\"_blank\">PortSwigger{{ rule.PortSwigger_Title }}</a></li>\n    <li><a href=\"{{ rule.CWE_Link }}\" target=\"_blank\">{{ rule.CWE_Title }}</a></li>\n  </ul>\n</div>\n");

/***/ }),

/***/ "./node_modules/tslib/tslib.es6.js":
/*!*****************************************!*\
  !*** ./node_modules/tslib/tslib.es6.js ***!
  \*****************************************/
/*! exports provided: __extends, __assign, __rest, __decorate, __param, __metadata, __awaiter, __generator, __createBinding, __exportStar, __values, __read, __spread, __spreadArrays, __await, __asyncGenerator, __asyncDelegator, __asyncValues, __makeTemplateObject, __importStar, __importDefault, __classPrivateFieldGet, __classPrivateFieldSet */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__extends", function() { return __extends; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__assign", function() { return __assign; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__rest", function() { return __rest; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__decorate", function() { return __decorate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__param", function() { return __param; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__metadata", function() { return __metadata; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__awaiter", function() { return __awaiter; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__generator", function() { return __generator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__createBinding", function() { return __createBinding; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__exportStar", function() { return __exportStar; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__values", function() { return __values; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__read", function() { return __read; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__spread", function() { return __spread; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__spreadArrays", function() { return __spreadArrays; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__await", function() { return __await; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__asyncGenerator", function() { return __asyncGenerator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__asyncDelegator", function() { return __asyncDelegator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__asyncValues", function() { return __asyncValues; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__makeTemplateObject", function() { return __makeTemplateObject; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__importStar", function() { return __importStar; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__importDefault", function() { return __importDefault; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__classPrivateFieldGet", function() { return __classPrivateFieldGet; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__classPrivateFieldSet", function() { return __classPrivateFieldSet; });
/*! *****************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */
/* global Reflect, Promise */

var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return extendStatics(d, b);
};

function __extends(d, b) {
    extendStatics(d, b);
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
}

var __assign = function() {
    __assign = Object.assign || function __assign(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    }
    return __assign.apply(this, arguments);
}

function __rest(s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
}

function __decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}

function __param(paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
}

function __metadata(metadataKey, metadataValue) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
}

function __awaiter(thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
}

function __generator(thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
}

function __createBinding(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}

function __exportStar(m, exports) {
    for (var p in m) if (p !== "default" && !exports.hasOwnProperty(p)) exports[p] = m[p];
}

function __values(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
}

function __read(o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
}

function __spread() {
    for (var ar = [], i = 0; i < arguments.length; i++)
        ar = ar.concat(__read(arguments[i]));
    return ar;
}

function __spreadArrays() {
    for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
    for (var r = Array(s), k = 0, i = 0; i < il; i++)
        for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
            r[k] = a[j];
    return r;
};

function __await(v) {
    return this instanceof __await ? (this.v = v, this) : new __await(v);
}

function __asyncGenerator(thisArg, _arguments, generator) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var g = generator.apply(thisArg, _arguments || []), i, q = [];
    return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
    function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
    function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
    function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
    function fulfill(value) { resume("next", value); }
    function reject(value) { resume("throw", value); }
    function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
}

function __asyncDelegator(o) {
    var i, p;
    return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
    function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
}

function __asyncValues(o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
    function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
    function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
}

function __makeTemplateObject(cooked, raw) {
    if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
    return cooked;
};

function __importStar(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result.default = mod;
    return result;
}

function __importDefault(mod) {
    return (mod && mod.__esModule) ? mod : { default: mod };
}

function __classPrivateFieldGet(receiver, privateMap) {
    if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to get private field on non-instance");
    }
    return privateMap.get(receiver);
}

function __classPrivateFieldSet(receiver, privateMap, value) {
    if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to set private field on non-instance");
    }
    privateMap.set(receiver, value);
    return value;
}


/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: routes, AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "routes", function() { return routes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _routeConfig__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./routeConfig */ "./src/app/routeConfig.ts");




// return an array of properly formatted routes from the routesConfig using the above helper function
// Due to an irregularity in Angular, you can't define the routes array and map routes into it at the same time
const routes = [];
routes.push(..._routeConfig__WEBPACK_IMPORTED_MODULE_3__["routesConfig"]);
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], AppRoutingModule);



/***/ }),

/***/ "./src/app/app.component.css":
/*!***********************************!*\
  !*** ./src/app/app.component.css ***!
  \***********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuY3NzIn0= */");

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _routeConfig__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./routeConfig */ "./src/app/routeConfig.ts");



let AppComponent = class AppComponent {
    constructor() {
        this.rules = _routeConfig__WEBPACK_IMPORTED_MODULE_2__["routesConfig"].filter(route => route.type === 'rule');
        this.title = 'angular8';
    }
};
AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-root',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./app.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./app.component.css */ "./src/app/app.component.css")).default]
    })
], AppComponent);



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm2015/platform-browser.js");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _rules_xss_xss_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./rules/xss/xss.component */ "./src/app/rules/xss/xss.component.ts");
/* harmony import */ var _rules_jsinjection_jsinjection_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./rules/jsinjection/jsinjection.component */ "./src/app/rules/jsinjection/jsinjection.component.ts");
/* harmony import */ var _rules_cookiemanipulation_cookiemanipulation_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./rules/cookiemanipulation/cookiemanipulation.component */ "./src/app/rules/cookiemanipulation/cookiemanipulation.component.ts");
/* harmony import */ var _rules_domainmanipulation_domainmanipulation_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./rules/domainmanipulation/domainmanipulation.component */ "./src/app/rules/domainmanipulation/domainmanipulation.component.ts");
/* harmony import */ var _rules_request_header_manipulation_request_header_manipulation_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./rules/request-header-manipulation/request-header-manipulation.component */ "./src/app/rules/request-header-manipulation/request-header-manipulation.component.ts");
/* harmony import */ var _rules_open_redirection_open_redirection_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./rules/open-redirection/open-redirection.component */ "./src/app/rules/open-redirection/open-redirection.component.ts");
/* harmony import */ var _rules_link_manipulation_link_manipulation_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./rules/link-manipulation/link-manipulation.component */ "./src/app/rules/link-manipulation/link-manipulation.component.ts");
/* harmony import */ var _rules_web_message_manipulation_web_message_manipulation_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./rules/web-message-manipulation/web-message-manipulation.component */ "./src/app/rules/web-message-manipulation/web-message-manipulation.component.ts");
/* harmony import */ var _sources_url_document_base_uri_document_base_uri_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./sources/url/document-base-uri/document-base-uri.component */ "./src/app/sources/url/document-base-uri/document-base-uri.component.ts");
/* harmony import */ var _sources_url_location_document_uri_location_document_uri_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./sources/url/location-document-uri/location-document-uri.component */ "./src/app/sources/url/location-document-uri/location-document-uri.component.ts");
/* harmony import */ var _sources_url_location_hash_location_hash_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./sources/url/location-hash/location-hash.component */ "./src/app/sources/url/location-hash/location-hash.component.ts");
/* harmony import */ var _sources_url_location_host_location_host_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./sources/url/location-host/location-host.component */ "./src/app/sources/url/location-host/location-host.component.ts");
/* harmony import */ var _sources_url_location_hostname_location_hostname_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./sources/url/location-hostname/location-hostname.component */ "./src/app/sources/url/location-hostname/location-hostname.component.ts");
/* harmony import */ var _sources_url_location_href_location_href_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./sources/url/location-href/location-href.component */ "./src/app/sources/url/location-href/location-href.component.ts");
/* harmony import */ var _sources_url_location_origin_location_origin_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./sources/url/location-origin/location-origin.component */ "./src/app/sources/url/location-origin/location-origin.component.ts");
/* harmony import */ var _sources_url_location_pathname_location_pathname_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./sources/url/location-pathname/location-pathname.component */ "./src/app/sources/url/location-pathname/location-pathname.component.ts");
/* harmony import */ var _sources_url_location_search_location_search_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./sources/url/location-search/location-search.component */ "./src/app/sources/url/location-search/location-search.component.ts");
/* harmony import */ var _sources_url_location_url_location_url_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./sources/url/location-url/location-url.component */ "./src/app/sources/url/location-url/location-url.component.ts");
/* harmony import */ var _sources_url_window_location_window_location_component__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./sources/url/window-location/window-location.component */ "./src/app/sources/url/window-location/window-location.component.ts");
/* harmony import */ var _sources_url_document_url_document_url_component__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./sources/url/document-url/document-url.component */ "./src/app/sources/url/document-url/document-url.component.ts");
/* harmony import */ var _sources_communication_document_cookie_document_cookie_component__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./sources/communication/document-cookie/document-cookie.component */ "./src/app/sources/communication/document-cookie/document-cookie.component.ts");
/* harmony import */ var _sources_communication_message_event_data_message_event_data_component__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./sources/communication/message-event-data/message-event-data.component */ "./src/app/sources/communication/message-event-data/message-event-data.component.ts");
/* harmony import */ var _sources_window_document_storage_getitem_storage_getitem_component__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ./sources/window-document/storage-getitem/storage-getitem.component */ "./src/app/sources/window-document/storage-getitem/storage-getitem.component.ts");
/* harmony import */ var _sources_window_document_document_referrer_document_referrer_component__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ./sources/window-document/document-referrer/document-referrer.component */ "./src/app/sources/window-document/document-referrer/document-referrer.component.ts");
/* harmony import */ var _sources_window_document_element_value_element_value_component__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ./sources/window-document/element-value/element-value.component */ "./src/app/sources/window-document/element-value/element-value.component.ts");
/* harmony import */ var _sources_window_document_window_frame_element_window_frame_element_component__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ./sources/window-document/window-frame-element/window-frame-element.component */ "./src/app/sources/window-document/window-frame-element/window-frame-element.component.ts");
/* harmony import */ var _sources_window_document_window_frames_window_frames_component__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ./sources/window-document/window-frames/window-frames.component */ "./src/app/sources/window-document/window-frames/window-frames.component.ts");
/* harmony import */ var _sources_window_document_window_name_window_name_component__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! ./sources/window-document/window-name/window-name.component */ "./src/app/sources/window-document/window-name/window-name.component.ts");
/* harmony import */ var _sources_window_document_window_prompt_window_prompt_component__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! ./sources/window-document/window-prompt/window-prompt.component */ "./src/app/sources/window-document/window-prompt/window-prompt.component.ts");
/* harmony import */ var _sources_sources_component__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! ./sources/sources.component */ "./src/app/sources/sources.component.ts");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm2015/ng-bootstrap.js");
/* harmony import */ var _templates_rule_rule_component__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! ./templates/rule/rule.component */ "./src/app/templates/rule/rule.component.ts");
/* harmony import */ var _rules_local_file_path_manipulation_local_file_path_manipulation_component__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! ./rules/local-file-path-manipulation/local-file-path-manipulation.component */ "./src/app/rules/local-file-path-manipulation/local-file-path-manipulation.component.ts");
/* harmony import */ var _rules_html5_storage_manipulation_html5_storage_manipulation_component__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! ./rules/html5-storage-manipulation/html5-storage-manipulation.component */ "./src/app/rules/html5-storage-manipulation/html5-storage-manipulation.component.ts");
/* harmony import */ var _rules_json_injection_json_injection_component__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! ./rules/json-injection/json-injection.component */ "./src/app/rules/json-injection/json-injection.component.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");








































let AppModule = class AppModule {
};
AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_39__["NgModule"])({
        declarations: [
            _app_component__WEBPACK_IMPORTED_MODULE_3__["AppComponent"],
            _rules_xss_xss_component__WEBPACK_IMPORTED_MODULE_4__["XssComponent"],
            _rules_jsinjection_jsinjection_component__WEBPACK_IMPORTED_MODULE_5__["JsinjectionComponent"],
            _rules_cookiemanipulation_cookiemanipulation_component__WEBPACK_IMPORTED_MODULE_6__["CookiemanipulationComponent"],
            _rules_domainmanipulation_domainmanipulation_component__WEBPACK_IMPORTED_MODULE_7__["DomainmanipulationComponent"],
            _rules_request_header_manipulation_request_header_manipulation_component__WEBPACK_IMPORTED_MODULE_8__["RequestHeaderManipulationComponent"],
            _sources_sources_component__WEBPACK_IMPORTED_MODULE_33__["SourcesComponent"],
            _sources_url_document_base_uri_document_base_uri_component__WEBPACK_IMPORTED_MODULE_12__["DocumentBaseUriComponent"],
            _sources_url_location_document_uri_location_document_uri_component__WEBPACK_IMPORTED_MODULE_13__["LocationDocumentUriComponent"],
            _sources_url_window_location_window_location_component__WEBPACK_IMPORTED_MODULE_22__["WindowLocationComponent"],
            _sources_url_location_hash_location_hash_component__WEBPACK_IMPORTED_MODULE_14__["LocationHashComponent"],
            _sources_url_location_host_location_host_component__WEBPACK_IMPORTED_MODULE_15__["LocationHostComponent"],
            _sources_url_location_hostname_location_hostname_component__WEBPACK_IMPORTED_MODULE_16__["LocationHostnameComponent"],
            _sources_url_location_href_location_href_component__WEBPACK_IMPORTED_MODULE_17__["LocationHrefComponent"],
            _sources_url_location_origin_location_origin_component__WEBPACK_IMPORTED_MODULE_18__["LocationOriginComponent"],
            _sources_url_location_pathname_location_pathname_component__WEBPACK_IMPORTED_MODULE_19__["LocationPathnameComponent"],
            _sources_url_location_search_location_search_component__WEBPACK_IMPORTED_MODULE_20__["LocationSearchComponent"],
            _sources_url_location_url_location_url_component__WEBPACK_IMPORTED_MODULE_21__["LocationUrlComponent"],
            _sources_communication_document_cookie_document_cookie_component__WEBPACK_IMPORTED_MODULE_24__["DocumentCookieComponent"],
            _sources_communication_message_event_data_message_event_data_component__WEBPACK_IMPORTED_MODULE_25__["MessageEventDataComponent"],
            _sources_window_document_storage_getitem_storage_getitem_component__WEBPACK_IMPORTED_MODULE_26__["StorageGetitemComponent"],
            _sources_url_document_url_document_url_component__WEBPACK_IMPORTED_MODULE_23__["DocumentUrlComponent"],
            _sources_url_document_base_uri_document_base_uri_component__WEBPACK_IMPORTED_MODULE_12__["DocumentBaseUriComponent"],
            _sources_window_document_document_referrer_document_referrer_component__WEBPACK_IMPORTED_MODULE_27__["DocumentReferrerComponent"],
            _sources_window_document_element_value_element_value_component__WEBPACK_IMPORTED_MODULE_28__["ElementValueComponent"],
            _sources_window_document_window_frame_element_window_frame_element_component__WEBPACK_IMPORTED_MODULE_29__["WindowFrameElementComponent"],
            _sources_window_document_window_frames_window_frames_component__WEBPACK_IMPORTED_MODULE_30__["WindowFramesComponent"],
            _sources_window_document_window_name_window_name_component__WEBPACK_IMPORTED_MODULE_31__["WindowNameComponent"],
            _sources_window_document_window_prompt_window_prompt_component__WEBPACK_IMPORTED_MODULE_32__["WindowPromptComponent"],
            _templates_rule_rule_component__WEBPACK_IMPORTED_MODULE_35__["RuleComponent"],
            _rules_open_redirection_open_redirection_component__WEBPACK_IMPORTED_MODULE_9__["OpenRedirectionComponent"],
            _rules_link_manipulation_link_manipulation_component__WEBPACK_IMPORTED_MODULE_10__["LinkManipulationComponent"],
            _rules_web_message_manipulation_web_message_manipulation_component__WEBPACK_IMPORTED_MODULE_11__["WebMessageManipulationComponent"],
            _rules_local_file_path_manipulation_local_file_path_manipulation_component__WEBPACK_IMPORTED_MODULE_36__["LocalFilePathManipulationComponent"],
            _rules_html5_storage_manipulation_html5_storage_manipulation_component__WEBPACK_IMPORTED_MODULE_37__["Html5StorageManipulationComponent"],
            _rules_json_injection_json_injection_component__WEBPACK_IMPORTED_MODULE_38__["JsonInjectionComponent"]
        ],
        imports: [
            _app_routing_module__WEBPACK_IMPORTED_MODULE_2__["AppRoutingModule"],
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"],
            _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_34__["NgbModule"]
        ],
        providers: [],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_3__["AppComponent"]]
    })
], AppModule);



/***/ }),

/***/ "./src/app/routeConfig.ts":
/*!********************************!*\
  !*** ./src/app/routeConfig.ts ***!
  \********************************/
/*! exports provided: routesConfig */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "routesConfig", function() { return routesConfig; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _rules_xss_xss_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./rules/xss/xss.component */ "./src/app/rules/xss/xss.component.ts");
/* harmony import */ var _rules_jsinjection_jsinjection_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./rules/jsinjection/jsinjection.component */ "./src/app/rules/jsinjection/jsinjection.component.ts");
/* harmony import */ var _rules_cookiemanipulation_cookiemanipulation_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./rules/cookiemanipulation/cookiemanipulation.component */ "./src/app/rules/cookiemanipulation/cookiemanipulation.component.ts");
/* harmony import */ var _rules_domainmanipulation_domainmanipulation_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./rules/domainmanipulation/domainmanipulation.component */ "./src/app/rules/domainmanipulation/domainmanipulation.component.ts");
/* harmony import */ var _rules_request_header_manipulation_request_header_manipulation_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./rules/request-header-manipulation/request-header-manipulation.component */ "./src/app/rules/request-header-manipulation/request-header-manipulation.component.ts");
/* harmony import */ var _sources_sources_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./sources/sources.component */ "./src/app/sources/sources.component.ts");
/* harmony import */ var _sourceConfig__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./sourceConfig */ "./src/app/sourceConfig.ts");
/* harmony import */ var _rules_open_redirection_open_redirection_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./rules/open-redirection/open-redirection.component */ "./src/app/rules/open-redirection/open-redirection.component.ts");
/* harmony import */ var _rules_link_manipulation_link_manipulation_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./rules/link-manipulation/link-manipulation.component */ "./src/app/rules/link-manipulation/link-manipulation.component.ts");
/* harmony import */ var _rules_web_message_manipulation_web_message_manipulation_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./rules/web-message-manipulation/web-message-manipulation.component */ "./src/app/rules/web-message-manipulation/web-message-manipulation.component.ts");
/* harmony import */ var _rules_local_file_path_manipulation_local_file_path_manipulation_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./rules/local-file-path-manipulation/local-file-path-manipulation.component */ "./src/app/rules/local-file-path-manipulation/local-file-path-manipulation.component.ts");
/* harmony import */ var _rules_html5_storage_manipulation_html5_storage_manipulation_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./rules/html5-storage-manipulation/html5-storage-manipulation.component */ "./src/app/rules/html5-storage-manipulation/html5-storage-manipulation.component.ts");
/* harmony import */ var _rules_json_injection_json_injection_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./rules/json-injection/json-injection.component */ "./src/app/rules/json-injection/json-injection.component.ts");














const routesConfig = [
    { path: 'rules/xss', component: _rules_xss_xss_component__WEBPACK_IMPORTED_MODULE_1__["XssComponent"], title: 'XSS', type: 'rule' },
    { path: 'rules/jsinjection', component: _rules_jsinjection_jsinjection_component__WEBPACK_IMPORTED_MODULE_2__["JsinjectionComponent"], title: 'Javascript Injection', type: 'rule' },
    { path: 'rules/cookiemanipulation', component: _rules_cookiemanipulation_cookiemanipulation_component__WEBPACK_IMPORTED_MODULE_3__["CookiemanipulationComponent"], title: 'Cookie Manipulation', type: 'rule' },
    { path: 'rules/domainmanipulation', component: _rules_domainmanipulation_domainmanipulation_component__WEBPACK_IMPORTED_MODULE_4__["DomainmanipulationComponent"], title: 'Document Domain Manipulation', type: 'rule' },
    { path: 'rules/request-header-manipulation', component: _rules_request_header_manipulation_request_header_manipulation_component__WEBPACK_IMPORTED_MODULE_5__["RequestHeaderManipulationComponent"], title: 'Ajax request-header manipulation', type: 'rule' },
    { path: 'rules/open-redirection', component: _rules_open_redirection_open_redirection_component__WEBPACK_IMPORTED_MODULE_8__["OpenRedirectionComponent"], title: 'Open Redirection', type: 'rule' },
    { path: 'rules/link-manipulation', component: _rules_link_manipulation_link_manipulation_component__WEBPACK_IMPORTED_MODULE_9__["LinkManipulationComponent"], title: 'Link Manipulation', type: 'rule' },
    { path: 'rules/web-message-manipulation', component: _rules_web_message_manipulation_web_message_manipulation_component__WEBPACK_IMPORTED_MODULE_10__["WebMessageManipulationComponent"], title: 'Web Message Manipulation', type: 'rule' },
    { path: 'rules/filepath-manipulation', component: _rules_local_file_path_manipulation_local_file_path_manipulation_component__WEBPACK_IMPORTED_MODULE_11__["LocalFilePathManipulationComponent"], title: 'Local File Path Manipulation', type: 'rule' },
    { path: 'rules/storage-manipulation', component: _rules_html5_storage_manipulation_html5_storage_manipulation_component__WEBPACK_IMPORTED_MODULE_12__["Html5StorageManipulationComponent"], title: 'HTML5 Storage Manipulation', type: 'rule' },
    { path: 'rules/json-injection', component: _rules_json_injection_json_injection_component__WEBPACK_IMPORTED_MODULE_13__["JsonInjectionComponent"], title: 'JSON Injection', type: 'rule' },
    { path: 'sources', children: [
            { path: '', component: _sources_sources_component__WEBPACK_IMPORTED_MODULE_6__["SourcesComponent"], title: 'Sources', type: 'category' },
            ..._sourceConfig__WEBPACK_IMPORTED_MODULE_7__["sources"]
        ] }
];


/***/ }),

/***/ "./src/app/rules/cookiemanipulation/cookiemanipulation.component.css":
/*!***************************************************************************!*\
  !*** ./src/app/rules/cookiemanipulation/cookiemanipulation.component.css ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3J1bGVzL2Nvb2tpZW1hbmlwdWxhdGlvbi9jb29raWVtYW5pcHVsYXRpb24uY29tcG9uZW50LmNzcyJ9 */");

/***/ }),

/***/ "./src/app/rules/cookiemanipulation/cookiemanipulation.component.ts":
/*!**************************************************************************!*\
  !*** ./src/app/rules/cookiemanipulation/cookiemanipulation.component.ts ***!
  \**************************************************************************/
/*! exports provided: CookiemanipulationComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CookiemanipulationComponent", function() { return CookiemanipulationComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");



let CookiemanipulationComponent = class CookiemanipulationComponent {
    constructor(route) {
        this.route = route;
    }
    loadInput(dangerousCookieInput) {
        document.cookie = `userName=${dangerousCookieInput}`;
        this.cookies = this.getCookiesMap(document.cookie);
    }
    // checkForCookie(name: string) {
    //   let cookieString = document.cookie.match(name + '=[^;]+')
    //   return cookieString ? cookieString[0] : cookieString
    // }
    getCookiesMap(cookiesString) {
        return cookiesString.split(";")
            .map(function (cookieString) {
            return cookieString.trim().split("=");
        })
            .reduce(function (acc, curr) {
            acc[curr[0]] = curr[1];
            return acc;
        }, {});
    }
    loadHash() {
        this.loadInput(this.route.snapshot.queryParams['userName']);
    }
    ngOnInit() {
        this.cookies = this.getCookiesMap(document.cookie);
        console.log(this.cookies);
    }
};
CookiemanipulationComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] }
];
CookiemanipulationComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-cookiemanipulation',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./cookiemanipulation.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/rules/cookiemanipulation/cookiemanipulation.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./cookiemanipulation.component.css */ "./src/app/rules/cookiemanipulation/cookiemanipulation.component.css")).default]
    })
], CookiemanipulationComponent);



/***/ }),

/***/ "./src/app/rules/domainmanipulation/domainmanipulation.component.css":
/*!***************************************************************************!*\
  !*** ./src/app/rules/domainmanipulation/domainmanipulation.component.css ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3J1bGVzL2RvbWFpbm1hbmlwdWxhdGlvbi9kb21haW5tYW5pcHVsYXRpb24uY29tcG9uZW50LmNzcyJ9 */");

/***/ }),

/***/ "./src/app/rules/domainmanipulation/domainmanipulation.component.ts":
/*!**************************************************************************!*\
  !*** ./src/app/rules/domainmanipulation/domainmanipulation.component.ts ***!
  \**************************************************************************/
/*! exports provided: DomainmanipulationComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DomainmanipulationComponent", function() { return DomainmanipulationComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");



let DomainmanipulationComponent = class DomainmanipulationComponent {
    constructor(route) {
        this.route = route;
        this.rule = {
            name: 'Document Domain Manipulation',
            OWASP_Link: 'https://owasp.org/www-project-web-security-testing-guide/latest/4-Web_Application_Security_Testing/11-Client-side_Testing/07-Testing_Cross_Origin_Resource_Sharing',
            OWASP_Title: 'OWASP Testing Cross Origin Resource Sharing',
            CWE_Link: 'https://cwe.mitre.org/data/definitions/284.html',
            CWE_Title: 'CWE-284: Improper Access Control',
            PortSwigger_Link: 'https://portswigger.net/web-security/dom-based/document-domain-manipulation',
            PortSwigger_Title: 'DOM-based document-domain manipulation',
            description: `The document.domain property is used by browsers in their enforcement of the same origin policy. If two pages from different origins explicitly set the same document.domain value, then those two pages can interact in unrestricted ways. If an attacker can cause a page of a targeted website and another page they control (either directly, or via an XSS-like vulnerability) to set the same document.domain value, then the attacker may be able to fully compromise the target page via the page they already control. This opens up the same possibilities for exploitation as regular cross-site scripting (XSS) vulnerabilities.`,
            sinks: `vulnerability domain-manipulation: <dom::Document>.domain [~sanitized]`,
        };
    }
    ngOnInit() {
    }
    loadInput(dangerousCookieInput) {
        document.domain = dangerousCookieInput;
    }
    loadHash() {
        this.loadInput(this.route.snapshot.fragment);
    }
    checkForCookie() {
        const cookies = document.cookie.split(',').reduce((prev, current) => {
            const [name, ...value] = current.split('=');
            prev[name] = value.join('=');
            return prev;
        }, {});
        document.domain = cookies['redirect'];
    }
    ;
};
DomainmanipulationComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] }
];
DomainmanipulationComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-domainmanipulation',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./domainmanipulation.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/rules/domainmanipulation/domainmanipulation.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./domainmanipulation.component.css */ "./src/app/rules/domainmanipulation/domainmanipulation.component.css")).default]
    })
], DomainmanipulationComponent);



/***/ }),

/***/ "./src/app/rules/html5-storage-manipulation/html5-storage-manipulation.component.css":
/*!*******************************************************************************************!*\
  !*** ./src/app/rules/html5-storage-manipulation/html5-storage-manipulation.component.css ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3J1bGVzL2h0bWw1LXN0b3JhZ2UtbWFuaXB1bGF0aW9uL2h0bWw1LXN0b3JhZ2UtbWFuaXB1bGF0aW9uLmNvbXBvbmVudC5jc3MifQ== */");

/***/ }),

/***/ "./src/app/rules/html5-storage-manipulation/html5-storage-manipulation.component.ts":
/*!******************************************************************************************!*\
  !*** ./src/app/rules/html5-storage-manipulation/html5-storage-manipulation.component.ts ***!
  \******************************************************************************************/
/*! exports provided: Html5StorageManipulationComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Html5StorageManipulationComponent", function() { return Html5StorageManipulationComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");



let Html5StorageManipulationComponent = class Html5StorageManipulationComponent {
    constructor(route) {
        this.route = route;
        this.rule = {
            name: 'HTML5 Storage Manipulation',
            OWASP_Link: 'https://cheatsheetseries.owasp.org/cheatsheets/HTML5_Security_Cheat_Sheet.html',
            OWASP_Title: 'HTML5 Security Cheat Sheet',
            CWE_Link: 'https://cwe.mitre.org/data/definitions/921.html',
            CWE_Title: 'CWE-921: Storage of Sensitive Data in a Mechanism without Access Control',
            PortSwigger_Link: 'https://portswigger.net/web-security/dom-based/html5-storage-manipulation',
            PortSwigger_Title: 'DOM-based HTML5-storage manipulation',
            description: `HTML5-storage manipulation vulnerabilities arise when a script stores attacker-controllable data in the HTML5 storage of the web browser (either localStorage or sessionStorage). An attacker may be able to use this behavior to construct a URL that, if visited by another user, will cause the user's browser to store attacker-controllable data.

    This behavior does not in itself constitute a security vulnerability. However, if the application later reads data back from storage and processes it in an unsafe way, an attacker may be able to leverage the storage mechanism to deliver other DOM-based attacks, such as cross-site scripting and JavaScript injection.`,
            sinks: `vulnerability storage-manipulation: <dom::Storage>.setItem(_, *) [~sanitized]`,
        };
    }
    loadLocalStorage() {
        document.getElementById('vulnerableContent').innerHTML = localStorage.getItem('userName');
    }
    loadInput(dangerousInput) {
        localStorage.setItem('userName', dangerousInput);
    }
    checkForCookie() {
        const cookies = document.cookie.split(',').reduce((prev, current) => {
            const [name, ...value] = current.split('=');
            prev[name] = value.join('=');
            return prev;
        }, {});
        this.loadInput(cookies['webMessage']);
    }
    ;
    loadHash() {
        this.loadInput(this.route.snapshot.queryParams['localStorage']);
    }
    ngOnInit() {
    }
};
Html5StorageManipulationComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] }
];
Html5StorageManipulationComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-html5-storage-manipulation',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./html5-storage-manipulation.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/rules/html5-storage-manipulation/html5-storage-manipulation.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./html5-storage-manipulation.component.css */ "./src/app/rules/html5-storage-manipulation/html5-storage-manipulation.component.css")).default]
    })
], Html5StorageManipulationComponent);



/***/ }),

/***/ "./src/app/rules/jsinjection/jsinjection.component.css":
/*!*************************************************************!*\
  !*** ./src/app/rules/jsinjection/jsinjection.component.css ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3J1bGVzL2pzaW5qZWN0aW9uL2pzaW5qZWN0aW9uLmNvbXBvbmVudC5jc3MifQ== */");

/***/ }),

/***/ "./src/app/rules/jsinjection/jsinjection.component.ts":
/*!************************************************************!*\
  !*** ./src/app/rules/jsinjection/jsinjection.component.ts ***!
  \************************************************************/
/*! exports provided: JsinjectionComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "JsinjectionComponent", function() { return JsinjectionComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");



let JsinjectionComponent = class JsinjectionComponent {
    constructor(route) {
        this.route = route;
    }
    loadInput(dangerousString) {
        eval(dangerousString);
    }
    loadHash() {
        eval(this.route.snapshot.fragment);
    }
    checkForCookie() {
        const cookies = document.cookie.split(',').reduce((prev, current) => {
            const [name, ...value] = current.split('=');
            prev[name] = value.join('=');
            return prev;
        }, {});
        eval(cookies['username']);
    }
    ;
    ngOnInit() {
    }
};
JsinjectionComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] }
];
JsinjectionComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-jsinjection',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./jsinjection.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/rules/jsinjection/jsinjection.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./jsinjection.component.css */ "./src/app/rules/jsinjection/jsinjection.component.css")).default]
    })
], JsinjectionComponent);



/***/ }),

/***/ "./src/app/rules/json-injection/json-injection.component.css":
/*!*******************************************************************!*\
  !*** ./src/app/rules/json-injection/json-injection.component.css ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3J1bGVzL2pzb24taW5qZWN0aW9uL2pzb24taW5qZWN0aW9uLmNvbXBvbmVudC5jc3MifQ== */");

/***/ }),

/***/ "./src/app/rules/json-injection/json-injection.component.ts":
/*!******************************************************************!*\
  !*** ./src/app/rules/json-injection/json-injection.component.ts ***!
  \******************************************************************/
/*! exports provided: JsonInjectionComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "JsonInjectionComponent", function() { return JsonInjectionComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");



let JsonInjectionComponent = class JsonInjectionComponent {
    constructor(route) {
        this.route = route;
        this.rule = {
            name: 'JSON Injection',
            OWASP_Link: 'https://owasp.org/www-project-top-ten/2017/A1_2017-Injection',
            OWASP_Title: 'JSON Injection at OWASP',
            CWE_Link: 'https://cwe.mitre.org/data/definitions/74.html',
            CWE_Title: 'CWE-74: Improper Neutralization of Special Elements in Output Used by a Downstream Component ("Injection")',
            PortSwigger_Link: 'https://portswigger.net/web-security/dom-based/client-side-json-injection',
            PortSwigger_Title: 'DOM-based client-side JSON injection',
            description: `DOM-based JSON-injection vulnerabilities arise when a script incorporates attacker-controllable data into a string that is parsed as a JSON data structure and then processed by the application. An attacker may be able to use this behavior to construct a URL that, if visited by another user, will cause arbitrary JSON data to be processed.`,
            sinks: `vulnerability json-injection: <stdlib::JSON>.parse(*) [~sanitized]`,
        };
    }
    loadInput(dangerousInput) {
        document.getElementById('vulnerableId').innerHTML = JSON.parse(dangerousInput).text;
    }
    checkForCookie() {
        const cookies = document.cookie.split(',').reduce((prev, current) => {
            const [name, ...value] = current.split('=');
            prev[name] = value.join('=');
            return prev;
        }, {});
        this.loadInput(cookies['json']);
    }
    ;
    loadHash() {
        this.loadInput(JSON.parse(this.route.snapshot.queryParams['json']));
    }
    ngOnInit() { }
};
JsonInjectionComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] }
];
JsonInjectionComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-json-injection',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./json-injection.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/rules/json-injection/json-injection.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./json-injection.component.css */ "./src/app/rules/json-injection/json-injection.component.css")).default]
    })
], JsonInjectionComponent);



/***/ }),

/***/ "./src/app/rules/link-manipulation/link-manipulation.component.css":
/*!*************************************************************************!*\
  !*** ./src/app/rules/link-manipulation/link-manipulation.component.css ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3J1bGVzL2xpbmstbWFuaXB1bGF0aW9uL2xpbmstbWFuaXB1bGF0aW9uLmNvbXBvbmVudC5jc3MifQ== */");

/***/ }),

/***/ "./src/app/rules/link-manipulation/link-manipulation.component.ts":
/*!************************************************************************!*\
  !*** ./src/app/rules/link-manipulation/link-manipulation.component.ts ***!
  \************************************************************************/
/*! exports provided: LinkManipulationComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LinkManipulationComponent", function() { return LinkManipulationComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");



let LinkManipulationComponent = class LinkManipulationComponent {
    constructor(route) {
        this.route = route;
        this.rule = {
            name: 'Link Manipulation',
            OWASP_Link: 'https://cheatsheetseries.owasp.org/cheatsheets/Unvalidated_Redirects_and_Forwards_Cheat_Sheet.html',
            OWASP_Title: 'OWASP Unvalidated Redirects and Forwards Cheat Sheet',
            CWE_Link: 'https://cwe.mitre.org/data/definitions/233.html',
            CWE_Title: 'CWE-233: Improper Handling of Parameters',
            PortSwigger_Link: 'https://portswigger.net/web-security/dom-based/link-manipulation',
            PortSwigger_Title: 'DOM-based link manipulation',
            description: `DOM-based link-manipulation vulnerabilities arise when a script writes attacker-controllable data to a navigation target within the current page, such as a clickable link or the submission URL of a form. An attacker might be able to use this vulnerability to construct a URL that, if visited by another application user, will modify the target of links within the response.`,
            sinks: `vulnerability link-manipulation: <dom::Element>.href   [~sanitized]
vulnerability link-manipulation: <dom::HTMLLinkElement>.href   [~sanitized]
vulnerability link-manipulation: <dom::HTMLEmbedElement>.src   [~sanitized]
vulnerability link-manipulation: <dom::HTMLFrameElement>.src   [~sanitized]
vulnerability link-manipulation: <dom::HTMLIFrameElement>.src  [~sanitized]
vulnerability link-manipulation: <dom::HTMLImageElement>.src   [~sanitized]
vulnerability link-manipulation: <dom::HTMLInputElement>.src   [~sanitized]
vulnerability link-manipulation: <dom::HTMLMediaElement>.src   [~sanitized]
vulnerability link-manipulation: <dom::HTMLSourceElement>.src  [~sanitized]
vulnerability link-manipulation: <dom::HTMLTrackElement>.src   [~sanitized]
vulnerability link-manipulation: <dom::HTMLFormElement>.action [~sanitized]`,
        };
    }
    loadInput(dangerousInput) {
        const link = document.getElementById('vulnerableLink');
        link.href = dangerousInput;
    }
    loadHash() {
        this.loadInput(this.route.snapshot.fragment);
    }
    checkForCookie() {
        const cookies = document.cookie.split(',').reduce((prev, current) => {
            const [name, ...value] = current.split('=');
            prev[name] = value.join('=');
            return prev;
        }, {});
        this.loadInput(cookies['manipulatedLink']);
    }
    ;
    ngOnInit() {
    }
};
LinkManipulationComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] }
];
LinkManipulationComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-link-manipulation',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./link-manipulation.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/rules/link-manipulation/link-manipulation.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./link-manipulation.component.css */ "./src/app/rules/link-manipulation/link-manipulation.component.css")).default]
    })
], LinkManipulationComponent);



/***/ }),

/***/ "./src/app/rules/local-file-path-manipulation/local-file-path-manipulation.component.css":
/*!***********************************************************************************************!*\
  !*** ./src/app/rules/local-file-path-manipulation/local-file-path-manipulation.component.css ***!
  \***********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3J1bGVzL2xvY2FsLWZpbGUtcGF0aC1tYW5pcHVsYXRpb24vbG9jYWwtZmlsZS1wYXRoLW1hbmlwdWxhdGlvbi5jb21wb25lbnQuY3NzIn0= */");

/***/ }),

/***/ "./src/app/rules/local-file-path-manipulation/local-file-path-manipulation.component.ts":
/*!**********************************************************************************************!*\
  !*** ./src/app/rules/local-file-path-manipulation/local-file-path-manipulation.component.ts ***!
  \**********************************************************************************************/
/*! exports provided: LocalFilePathManipulationComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LocalFilePathManipulationComponent", function() { return LocalFilePathManipulationComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");



let LocalFilePathManipulationComponent = class LocalFilePathManipulationComponent {
    constructor(route) {
        this.route = route;
        this.rule = {
            name: 'Local File Path Manipulation',
            OWASP_Link: 'https://owasp.org/www-community/attacks/Path_Traversal',
            OWASP_Title: 'Path Traversal',
            CWE_Link: 'https://cwe.mitre.org/data/definitions/73.html',
            CWE_Title: 'CWE-73: External Control of File Name or Path',
            PortSwigger_Link: 'https://portswigger.net/web-security/dom-based/local-file-path-manipulation',
            PortSwigger_Title: 'DOM-based local file-path manipulation',
            description: `Local file-path manipulation vulnerabilities arise when a script passes attacker-controllable data to a file-handling API as the filename parameter. An attacker may be able to use this vulnerability to construct a URL that, if visited by another user, will cause the user's browser to open an arbitrary local file.`,
            sinks: `vulnerability filepath-manipulation: <dom::FileReader>.readAsArrayBuffer(*)  [~sanitized]
vulnerability filepath-manipulation: <dom::FileReader>.readAsBinaryString(*) [~sanitized]
vulnerability filepath-manipulation: <dom::FileReader>.readAsDataURL(*)      [~sanitized]
vulnerability filepath-manipulation: <dom::FileReader>.readAsText(*)         [~sanitized]`,
        };
    }
    readFiles(event) {
        var fileList = event.target.files;
        console.log(fileList);
    }
    loadInput(dangerousInput) {
        window.addEventListener('message', function (e) {
            document.getElementById('vulnerableId').innerHTML = e.data;
        });
        window.postMessage(dangerousInput, '*');
    }
    checkForCookie() {
        const cookies = document.cookie.split(',').reduce((prev, current) => {
            const [name, ...value] = current.split('=');
            prev[name] = value.join('=');
            return prev;
        }, {});
        this.loadInput(cookies['webMessage']);
    }
    ;
    loadHash() {
        this.loadInput(this.route.snapshot.queryParams['webMessage']);
    }
    ngOnInit() {
    }
};
LocalFilePathManipulationComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] }
];
LocalFilePathManipulationComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-local-file-path-manipulation',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./local-file-path-manipulation.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/rules/local-file-path-manipulation/local-file-path-manipulation.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./local-file-path-manipulation.component.css */ "./src/app/rules/local-file-path-manipulation/local-file-path-manipulation.component.css")).default]
    })
], LocalFilePathManipulationComponent);



/***/ }),

/***/ "./src/app/rules/open-redirection/open-redirection.component.css":
/*!***********************************************************************!*\
  !*** ./src/app/rules/open-redirection/open-redirection.component.css ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3J1bGVzL29wZW4tcmVkaXJlY3Rpb24vb3Blbi1yZWRpcmVjdGlvbi5jb21wb25lbnQuY3NzIn0= */");

/***/ }),

/***/ "./src/app/rules/open-redirection/open-redirection.component.ts":
/*!**********************************************************************!*\
  !*** ./src/app/rules/open-redirection/open-redirection.component.ts ***!
  \**********************************************************************/
/*! exports provided: OpenRedirectionComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OpenRedirectionComponent", function() { return OpenRedirectionComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");



let OpenRedirectionComponent = class OpenRedirectionComponent {
    constructor(route) {
        this.route = route;
        this.rule = {
            name: 'Open Redirection',
            OWASP_Link: 'https://cheatsheetseries.owasp.org/cheatsheets/Unvalidated_Redirects_and_Forwards_Cheat_Sheet.html',
            OWASP_Title: 'OWASP Unvalidated Redirects and Forwards Cheat Sheet',
            CWE_Link: 'https://cwe.mitre.org/data/definitions/601.html',
            CWE_Title: 'CWE-601: URL Redirection to Untrusted Site (Open Redirect)',
            PortSwigger_Link: 'https://portswigger.net/web-security/dom-based/open-redirection',
            PortSwigger_Title: 'DOM-based open redirection',
            description: `Unvalidated redirects and forwards are possible when a web application accepts untrusted input that could cause the web application to redirect the request to a URL contained within untrusted input. By modifying untrusted URL input to a malicious site, an attacker may successfully launch a phishing scam and steal user credentials.`,
            sinks: `vulnerability open-redirection: new <dom::LocationConstructor>(*)  [~sanitized] // this may or may not work, the problem is \`location = ...\`
vulnerability open-redirection: <dom::Location>.host            [~sanitized]
vulnerability open-redirection: <dom::Location>.hostname        [~sanitized]
vulnerability open-redirection: <dom::Location>.href            [~sanitized]
vulnerability open-redirection: <dom::Location>.assign(*)       [~sanitized]
vulnerability open-redirection: <dom::Location>.replace(*)      [~sanitized]
vulnerability open-redirection: open(*)                         [~sanitized]
vulnerability open-redirection: <dom::Document>.open(*)         [~sanitized]
vulnerability open-redirection: <dom::Window>.open(*)           [~sanitized]
vulnerability open-redirection: <dom::HTMLIFrameElement>.srcdoc [~sanitized]`,
        };
    }
    loadInput(dangerousCookieInput) {
        window.location.href = dangerousCookieInput;
    }
    loadHash() {
        this.loadInput(this.route.snapshot.fragment);
    }
    checkForCookie() {
        const cookies = document.cookie.split(',').reduce((prev, current) => {
            const [name, ...value] = current.split('=');
            prev[name] = value.join('=');
            return prev;
        }, {});
        this.loadInput(cookies['redirect']);
    }
    ;
    ngOnInit() { }
};
OpenRedirectionComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] }
];
OpenRedirectionComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-open-redirection',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./open-redirection.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/rules/open-redirection/open-redirection.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./open-redirection.component.css */ "./src/app/rules/open-redirection/open-redirection.component.css")).default]
    })
], OpenRedirectionComponent);



/***/ }),

/***/ "./src/app/rules/request-header-manipulation/request-header-manipulation.component.css":
/*!*********************************************************************************************!*\
  !*** ./src/app/rules/request-header-manipulation/request-header-manipulation.component.css ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3J1bGVzL3JlcXVlc3QtaGVhZGVyLW1hbmlwdWxhdGlvbi9yZXF1ZXN0LWhlYWRlci1tYW5pcHVsYXRpb24uY29tcG9uZW50LmNzcyJ9 */");

/***/ }),

/***/ "./src/app/rules/request-header-manipulation/request-header-manipulation.component.ts":
/*!********************************************************************************************!*\
  !*** ./src/app/rules/request-header-manipulation/request-header-manipulation.component.ts ***!
  \********************************************************************************************/
/*! exports provided: RequestHeaderManipulationComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RequestHeaderManipulationComponent", function() { return RequestHeaderManipulationComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");



let RequestHeaderManipulationComponent = class RequestHeaderManipulationComponent {
    constructor(route) {
        this.route = route;
        this.rule = {
            name: 'Request Header Manipulation',
            OWASP_Link: 'https://cheatsheetseries.owasp.org/cheatsheets/HTTP_Headers_Cheat_Sheet.html',
            OWASP_Title: 'OWASP HTTP Security Response Headers Cheat Sheet',
            CWE_Link: 'https://cwe.mitre.org/data/definitions/345.html',
            CWE_Title: 'CWE-345: Insufficient Verification of Data Authenticity',
            PortSwigger_Link: 'https://portswigger.net/web-security/dom-based/ajax-request-header-manipulation',
            PortSwigger_Title: 'DOM-based Ajax request-header manipulation',
            description: `Ajax request-header manipulation vulnerabilities arise when a script writes attacker-controllable data into the request header of an Ajax request that is issued using an XmlHttpRequest object. An attacker may be able to use this vulnerability to construct a URL that, if visited by another user, will set an arbitrary header in the subsequent Ajax request. This can then be used as a starting point to chain together other kinds of attack, thereby increasing the potential severity of this vulnerability.`,
            sinks: `vulnerability header-manipulation: <dom::WindowOrWorkerGlobalScope>.fetch(*) [~sanitized]
vulnerability header-manipulation: fetch(*)                                  [~sanitized]
vulnerability header-manipulation: <dom::XMLHttpRequest>.setRequestHeader(*)                     [~sanitized]
vulnerability header-manipulation: <dom::XMLHttpRequest>.setRequestHeader(_, *)                  [~sanitized]
vulnerability ajax-response-header-manipulation: <dom::XMLHttpRequest>.getResponseHeader(*)           [~sanitized]`,
        };
    }
    loadInput(dangerousInput) {
        this.makeApiCall(dangerousInput);
    }
    loadHash() {
        this.loadInput(this.route.snapshot.fragment);
    }
    checkForCookie() {
        const cookies = document.cookie.split(',').reduce((prev, current) => {
            const [name, ...value] = current.split('=');
            prev[name] = value.join('=');
            return prev;
        }, {});
        this.loadInput(cookies['badHeader']);
    }
    ;
    makeApiCall(headerValue) {
        fetch('http://example.com/movies.json', {
            headers: {
                'maliciousHeader': headerValue
            }
        });
    }
    ngOnInit() {
    }
};
RequestHeaderManipulationComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] }
];
RequestHeaderManipulationComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-request-header-manipulation',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./request-header-manipulation.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/rules/request-header-manipulation/request-header-manipulation.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./request-header-manipulation.component.css */ "./src/app/rules/request-header-manipulation/request-header-manipulation.component.css")).default]
    })
], RequestHeaderManipulationComponent);



/***/ }),

/***/ "./src/app/rules/web-message-manipulation/web-message-manipulation.component.css":
/*!***************************************************************************************!*\
  !*** ./src/app/rules/web-message-manipulation/web-message-manipulation.component.css ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3J1bGVzL3dlYi1tZXNzYWdlLW1hbmlwdWxhdGlvbi93ZWItbWVzc2FnZS1tYW5pcHVsYXRpb24uY29tcG9uZW50LmNzcyJ9 */");

/***/ }),

/***/ "./src/app/rules/web-message-manipulation/web-message-manipulation.component.ts":
/*!**************************************************************************************!*\
  !*** ./src/app/rules/web-message-manipulation/web-message-manipulation.component.ts ***!
  \**************************************************************************************/
/*! exports provided: WebMessageManipulationComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WebMessageManipulationComponent", function() { return WebMessageManipulationComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");



let WebMessageManipulationComponent = class WebMessageManipulationComponent {
    constructor(route) {
        this.route = route;
        this.rule = {
            name: 'Web Message Manipulation',
            OWASP_Link: '',
            OWASP_Title: '',
            CWE_Link: '',
            CWE_Title: '',
            PortSwigger_Link: 'https://portswigger.net/web-security/dom-based/controlling-the-web-message-source',
            PortSwigger_Title: 'Controlling the web message source',
            description: `If a page handles incoming web messages in an unsafe way, for example, by not verifying the origin of incoming messages correctly in the event listener, properties and functions that are called by the event listener can potentially become sinks. For example, an attacker could host a malicious iframe and use the postMessage() method to pass web message data to the vulnerable event listener, which then sends the payload to a sink on the parent page. This behavior means that you can use web messages as the source for propagating malicious data to any of those sinks.`,
            sinks: `vulnerability webmessage-manipulation: <dom::Window>.postMessage(*) [~sanitized]
vulnerability webmessage-manipulation: <dom::Window>.postMessage(_, *) [~sanitized]
vulnerability webmessage-manipulation: <dom::Window>.postMessage(_, _, *) [~sanitized]`,
        };
    }
    loadInput(dangerousInput) {
        window.addEventListener('message', function (e) {
            document.getElementById('vulnerableId').innerHTML = e.data;
        });
        window.postMessage(dangerousInput, '*');
    }
    checkForCookie() {
        const cookies = document.cookie.split(',').reduce((prev, current) => {
            const [name, ...value] = current.split('=');
            prev[name] = value.join('=');
            return prev;
        }, {});
        this.loadInput(cookies['webMessage']);
    }
    ;
    loadHash() {
        this.loadInput(this.route.snapshot.queryParams['webMessage']);
    }
    ngOnInit() {
    }
};
WebMessageManipulationComponent.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] }
];
WebMessageManipulationComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-web-message-manipulation',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./web-message-manipulation.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/rules/web-message-manipulation/web-message-manipulation.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./web-message-manipulation.component.css */ "./src/app/rules/web-message-manipulation/web-message-manipulation.component.css")).default]
    })
], WebMessageManipulationComponent);



/***/ }),

/***/ "./src/app/rules/xss/xss.component.css":
/*!*********************************************!*\
  !*** ./src/app/rules/xss/xss.component.css ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3J1bGVzL3hzcy94c3MuY29tcG9uZW50LmNzcyJ9 */");

/***/ }),

/***/ "./src/app/rules/xss/xss.component.ts":
/*!********************************************!*\
  !*** ./src/app/rules/xss/xss.component.ts ***!
  \********************************************/
/*! exports provided: XssComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "XssComponent", function() { return XssComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm2015/platform-browser.js");
/* harmony import */ var postscribe__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! postscribe */ "./node_modules/postscribe/dist/postscribe.js");
/* harmony import */ var postscribe__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(postscribe__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_5__);







let XssComponent = class XssComponent {
    constructor(sanitizer) {
        this.sanitizer = sanitizer;
        this.username = "";
        this.activeIdString = "tab1";
        this.query = "";
        this.incomeValue = "0";
    }
    parseHash() {
        let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"]({ fromString: window.location.hash.substring(1) });
        var obj = {};
        for (var i = 0; i < params.keys().length; i++) {
            obj[params.keys()[i]] = decodeURI(params.get(params.keys()[i]));
        }
        return obj;
    }
    ngOnInit() {
        let hashObj = this.parseHash();
        if (hashObj['tab']) {
            this.activeIdString = hashObj['tab'];
        }
        if (hashObj['q']) {
            this.query = hashObj['q'];
        }
        switch (this.activeIdString) {
            case "tab2":
                this.incomeValue = this.query;
                break;
            default:
                break;
        }
    }
    ngAfterViewInit() {
        switch (this.activeIdString) {
            case "tab1":
                this.showSearchQuery(this.query);
                break;
            default:
                break;
        }
    }
    // private setTheoreticallySafeUrl(): void {
    //   let hash = window.location.hash.substring(1);
    //   this.theoreticallySafeUrl = this.sanitizer.bypassSecurityTrustUrl(hash);
    // }
    //Dcoument write using postscribe
    searchForSubscriber() {
        let val = this.subscriberNameInput.nativeElement.value;
        if (val) {
            window.location.hash = 'q=' + val;
            this.showSearchQuery(val);
        }
    }
    showSearchQuery(val) {
        postscribe__WEBPACK_IMPORTED_MODULE_4___default()('#searchQuery', val);
        jquery__WEBPACK_IMPORTED_MODULE_5__('#searchQuery').removeClass('hidden');
    }
    //nativeElement innerHtml
    calculateIncomeAndTaxes() {
        let val = this.incomeInput.nativeElement.value;
        if (val) {
            window.location.hash = 'tab=tab2&q=' + val;
            this.incomeValue = val;
            this.incomeValueOutput.nativeElement.innerHTML = this.incomeValue;
        }
    }
    getIncome() {
        if (this.incomeValue) {
            let val = this.incomeValue;
            //val = this.sanitizer.sanitize(SecurityContext.HTML, this.incomeValue);
            return this.sanitizer.bypassSecurityTrustHtml(val);
        }
    }
    getTaxes() {
        if (this.incomeValue) {
            let val = "Your income for taxes: " + this.incomeValue;
            val = this.sanitizer.sanitize(_angular_core__WEBPACK_IMPORTED_MODULE_1__["SecurityContext"].HTML, this.incomeValue);
            return this.sanitizer.bypassSecurityTrustHtml(val);
        }
    }
};
XssComponent.ctorParameters = () => [
    { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__["DomSanitizer"] }
];
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('subscriberNameInput', { static: false })
], XssComponent.prototype, "subscriberNameInput", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('incomeInput', { static: false })
], XssComponent.prototype, "incomeInput", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('incomeValueOutput', { static: false })
], XssComponent.prototype, "incomeValueOutput", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('taxesValueOutput', { static: false })
], XssComponent.prototype, "taxesValueOutput", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('tabset', { static: true })
], XssComponent.prototype, "tabset", void 0);
XssComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-xss',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./xss.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/rules/xss/xss.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./xss.component.css */ "./src/app/rules/xss/xss.component.css")).default]
    }),
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])()
], XssComponent);



/***/ }),

/***/ "./src/app/sourceConfig.ts":
/*!*********************************!*\
  !*** ./src/app/sourceConfig.ts ***!
  \*********************************/
/*! exports provided: types, sources */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "types", function() { return types; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sources", function() { return sources; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _sources_communication_document_cookie_document_cookie_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./sources/communication/document-cookie/document-cookie.component */ "./src/app/sources/communication/document-cookie/document-cookie.component.ts");
/* harmony import */ var _sources_communication_message_event_data_message_event_data_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./sources/communication/message-event-data/message-event-data.component */ "./src/app/sources/communication/message-event-data/message-event-data.component.ts");
/* harmony import */ var _sources_url_window_location_window_location_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./sources/url/window-location/window-location.component */ "./src/app/sources/url/window-location/window-location.component.ts");
/* harmony import */ var _sources_url_document_base_uri_document_base_uri_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./sources/url/document-base-uri/document-base-uri.component */ "./src/app/sources/url/document-base-uri/document-base-uri.component.ts");
/* harmony import */ var _sources_url_location_document_uri_location_document_uri_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./sources/url/location-document-uri/location-document-uri.component */ "./src/app/sources/url/location-document-uri/location-document-uri.component.ts");
/* harmony import */ var _sources_url_location_hash_location_hash_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./sources/url/location-hash/location-hash.component */ "./src/app/sources/url/location-hash/location-hash.component.ts");
/* harmony import */ var _sources_url_location_host_location_host_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./sources/url/location-host/location-host.component */ "./src/app/sources/url/location-host/location-host.component.ts");
/* harmony import */ var _sources_url_location_hostname_location_hostname_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./sources/url/location-hostname/location-hostname.component */ "./src/app/sources/url/location-hostname/location-hostname.component.ts");
/* harmony import */ var _sources_url_location_href_location_href_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./sources/url/location-href/location-href.component */ "./src/app/sources/url/location-href/location-href.component.ts");
/* harmony import */ var _sources_url_location_origin_location_origin_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./sources/url/location-origin/location-origin.component */ "./src/app/sources/url/location-origin/location-origin.component.ts");
/* harmony import */ var _sources_url_location_pathname_location_pathname_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./sources/url/location-pathname/location-pathname.component */ "./src/app/sources/url/location-pathname/location-pathname.component.ts");
/* harmony import */ var _sources_url_location_search_location_search_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./sources/url/location-search/location-search.component */ "./src/app/sources/url/location-search/location-search.component.ts");
/* harmony import */ var _sources_url_location_url_location_url_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./sources/url/location-url/location-url.component */ "./src/app/sources/url/location-url/location-url.component.ts");
/* harmony import */ var _sources_url_document_url_document_url_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./sources/url/document-url/document-url.component */ "./src/app/sources/url/document-url/document-url.component.ts");
/* harmony import */ var _sources_window_document_storage_getitem_storage_getitem_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./sources/window-document/storage-getitem/storage-getitem.component */ "./src/app/sources/window-document/storage-getitem/storage-getitem.component.ts");
/* harmony import */ var _sources_window_document_document_referrer_document_referrer_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./sources/window-document/document-referrer/document-referrer.component */ "./src/app/sources/window-document/document-referrer/document-referrer.component.ts");
/* harmony import */ var _sources_window_document_element_value_element_value_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./sources/window-document/element-value/element-value.component */ "./src/app/sources/window-document/element-value/element-value.component.ts");
/* harmony import */ var _sources_window_document_window_frame_element_window_frame_element_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./sources/window-document/window-frame-element/window-frame-element.component */ "./src/app/sources/window-document/window-frame-element/window-frame-element.component.ts");
/* harmony import */ var _sources_window_document_window_frames_window_frames_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./sources/window-document/window-frames/window-frames.component */ "./src/app/sources/window-document/window-frames/window-frames.component.ts");
/* harmony import */ var _sources_window_document_window_name_window_name_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./sources/window-document/window-name/window-name.component */ "./src/app/sources/window-document/window-name/window-name.component.ts");
/* harmony import */ var _sources_window_document_window_prompt_window_prompt_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./sources/window-document/window-prompt/window-prompt.component */ "./src/app/sources/window-document/window-prompt/window-prompt.component.ts");






















const types = ['url', 'window-document', 'communication'];
const sources = [
    //url based
    { path: 'url/document-base-uri', component: _sources_url_document_base_uri_document_base_uri_component__WEBPACK_IMPORTED_MODULE_4__["DocumentBaseUriComponent"], title: 'document.baseURI', type: 'url' },
    { path: 'url/document-url', component: _sources_url_document_url_document_url_component__WEBPACK_IMPORTED_MODULE_14__["DocumentUrlComponent"], title: 'document.url', type: 'url' },
    { path: 'url/location-document-uri', component: _sources_url_location_document_uri_location_document_uri_component__WEBPACK_IMPORTED_MODULE_5__["LocationDocumentUriComponent"], title: 'location.documentURI', type: 'url' },
    { path: 'url/location-hash', component: _sources_url_location_hash_location_hash_component__WEBPACK_IMPORTED_MODULE_6__["LocationHashComponent"], title: 'location.hash', type: 'url' },
    { path: 'url/location-host', component: _sources_url_location_host_location_host_component__WEBPACK_IMPORTED_MODULE_7__["LocationHostComponent"], title: 'location.host', type: 'url' },
    { path: 'url/location-hostname', component: _sources_url_location_hostname_location_hostname_component__WEBPACK_IMPORTED_MODULE_8__["LocationHostnameComponent"], title: 'location.hostname', type: 'url' },
    { path: 'url/location-search', component: _sources_url_location_search_location_search_component__WEBPACK_IMPORTED_MODULE_12__["LocationSearchComponent"], title: 'location.search', type: 'url' },
    { path: 'url/location-href', component: _sources_url_location_href_location_href_component__WEBPACK_IMPORTED_MODULE_9__["LocationHrefComponent"], title: 'location.href', type: 'url' },
    { path: 'url/location-origin', component: _sources_url_location_origin_location_origin_component__WEBPACK_IMPORTED_MODULE_10__["LocationOriginComponent"], title: 'location.origin', type: 'url' },
    { path: 'url/location-pathname', component: _sources_url_location_pathname_location_pathname_component__WEBPACK_IMPORTED_MODULE_11__["LocationPathnameComponent"], title: 'location.pathname', type: 'url' },
    { path: 'url/location-url', component: _sources_url_location_url_location_url_component__WEBPACK_IMPORTED_MODULE_13__["LocationUrlComponent"], title: 'location.url', type: 'url' },
    { path: 'communication/window-location', component: _sources_url_window_location_window_location_component__WEBPACK_IMPORTED_MODULE_3__["WindowLocationComponent"], title: 'window.location', type: 'url' },
    // communication based
    { path: 'communication/document-cookie', component: _sources_communication_document_cookie_document_cookie_component__WEBPACK_IMPORTED_MODULE_1__["DocumentCookieComponent"], title: 'document.cookie', type: 'communication' },
    { path: 'communication/message-event-data', component: _sources_communication_message_event_data_message_event_data_component__WEBPACK_IMPORTED_MODULE_2__["MessageEventDataComponent"], title: 'message.event.data', type: 'communication' },
    // { path: ''}
    // window document based
    { path: 'window-document/document-referrer', component: _sources_window_document_document_referrer_document_referrer_component__WEBPACK_IMPORTED_MODULE_16__["DocumentReferrerComponent"], title: 'document.referrer', type: 'window-document' },
    { path: 'window-document/element-value', component: _sources_window_document_element_value_element_value_component__WEBPACK_IMPORTED_MODULE_17__["ElementValueComponent"], title: 'element.value', type: 'window-document' },
    { path: 'window-document/storage-getitem', component: _sources_window_document_storage_getitem_storage_getitem_component__WEBPACK_IMPORTED_MODULE_15__["StorageGetitemComponent"], title: 'storage.getItem', type: 'window-document' },
    { path: 'window-document/window-frame-element', component: _sources_window_document_window_frame_element_window_frame_element_component__WEBPACK_IMPORTED_MODULE_18__["WindowFrameElementComponent"], title: 'window.frame.element', type: 'window-document' },
    { path: 'window-document/window-frames', component: _sources_window_document_window_frames_window_frames_component__WEBPACK_IMPORTED_MODULE_19__["WindowFramesComponent"], title: 'window.frames', type: 'window-document' },
    { path: 'window-document/window-name', component: _sources_window_document_window_name_window_name_component__WEBPACK_IMPORTED_MODULE_20__["WindowNameComponent"], title: 'window.name', type: 'window-document' },
    { path: 'window-document/window-prompt', component: _sources_window_document_window_prompt_window_prompt_component__WEBPACK_IMPORTED_MODULE_21__["WindowPromptComponent"], title: 'window.prompt', type: 'window-document' },
];


/***/ }),

/***/ "./src/app/sources/communication/document-cookie/document-cookie.component.css":
/*!*************************************************************************************!*\
  !*** ./src/app/sources/communication/document-cookie/document-cookie.component.css ***!
  \*************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NvdXJjZXMvY29tbXVuaWNhdGlvbi9kb2N1bWVudC1jb29raWUvZG9jdW1lbnQtY29va2llLmNvbXBvbmVudC5jc3MifQ== */");

/***/ }),

/***/ "./src/app/sources/communication/document-cookie/document-cookie.component.ts":
/*!************************************************************************************!*\
  !*** ./src/app/sources/communication/document-cookie/document-cookie.component.ts ***!
  \************************************************************************************/
/*! exports provided: DocumentCookieComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DocumentCookieComponent", function() { return DocumentCookieComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let DocumentCookieComponent = class DocumentCookieComponent {
    constructor() { }
    ngOnInit() {
    }
};
DocumentCookieComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-document-cookie',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./document-cookie.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/sources/communication/document-cookie/document-cookie.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./document-cookie.component.css */ "./src/app/sources/communication/document-cookie/document-cookie.component.css")).default]
    })
], DocumentCookieComponent);



/***/ }),

/***/ "./src/app/sources/communication/message-event-data/message-event-data.component.css":
/*!*******************************************************************************************!*\
  !*** ./src/app/sources/communication/message-event-data/message-event-data.component.css ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NvdXJjZXMvY29tbXVuaWNhdGlvbi9tZXNzYWdlLWV2ZW50LWRhdGEvbWVzc2FnZS1ldmVudC1kYXRhLmNvbXBvbmVudC5jc3MifQ== */");

/***/ }),

/***/ "./src/app/sources/communication/message-event-data/message-event-data.component.ts":
/*!******************************************************************************************!*\
  !*** ./src/app/sources/communication/message-event-data/message-event-data.component.ts ***!
  \******************************************************************************************/
/*! exports provided: MessageEventDataComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MessageEventDataComponent", function() { return MessageEventDataComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let MessageEventDataComponent = class MessageEventDataComponent {
    constructor() { }
    ngOnInit() {
    }
};
MessageEventDataComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-message-event-data',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./message-event-data.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/sources/communication/message-event-data/message-event-data.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./message-event-data.component.css */ "./src/app/sources/communication/message-event-data/message-event-data.component.css")).default]
    })
], MessageEventDataComponent);



/***/ }),

/***/ "./src/app/sources/sources.component.css":
/*!***********************************************!*\
  !*** ./src/app/sources/sources.component.css ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NvdXJjZXMvc291cmNlcy5jb21wb25lbnQuY3NzIn0= */");

/***/ }),

/***/ "./src/app/sources/sources.component.ts":
/*!**********************************************!*\
  !*** ./src/app/sources/sources.component.ts ***!
  \**********************************************/
/*! exports provided: SourcesComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SourcesComponent", function() { return SourcesComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _sourceConfig__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../sourceConfig */ "./src/app/sourceConfig.ts");



let SourcesComponent = class SourcesComponent {
    constructor() {
        this.communicationSources = _sourceConfig__WEBPACK_IMPORTED_MODULE_2__["sources"].filter(source => source.type === 'communication');
        this.urlSources = _sourceConfig__WEBPACK_IMPORTED_MODULE_2__["sources"].filter(source => source.type === 'url');
        this.windowDocumentSources = _sourceConfig__WEBPACK_IMPORTED_MODULE_2__["sources"].filter(source => source.type === 'window-document');
        this.types = _sourceConfig__WEBPACK_IMPORTED_MODULE_2__["types"];
    }
    ngOnInit() {
    }
};
SourcesComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-sources',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./sources.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/sources/sources.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./sources.component.css */ "./src/app/sources/sources.component.css")).default]
    })
], SourcesComponent);



/***/ }),

/***/ "./src/app/sources/url/document-base-uri/document-base-uri.component.css":
/*!*******************************************************************************!*\
  !*** ./src/app/sources/url/document-base-uri/document-base-uri.component.css ***!
  \*******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NvdXJjZXMvdXJsL2RvY3VtZW50LWJhc2UtdXJpL2RvY3VtZW50LWJhc2UtdXJpLmNvbXBvbmVudC5jc3MifQ== */");

/***/ }),

/***/ "./src/app/sources/url/document-base-uri/document-base-uri.component.ts":
/*!******************************************************************************!*\
  !*** ./src/app/sources/url/document-base-uri/document-base-uri.component.ts ***!
  \******************************************************************************/
/*! exports provided: DocumentBaseUriComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DocumentBaseUriComponent", function() { return DocumentBaseUriComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let DocumentBaseUriComponent = class DocumentBaseUriComponent {
    constructor() { }
    ngOnInit() {
    }
};
DocumentBaseUriComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-document-base-uri',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./document-base-uri.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/sources/url/document-base-uri/document-base-uri.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./document-base-uri.component.css */ "./src/app/sources/url/document-base-uri/document-base-uri.component.css")).default]
    })
], DocumentBaseUriComponent);



/***/ }),

/***/ "./src/app/sources/url/document-url/document-url.component.css":
/*!*********************************************************************!*\
  !*** ./src/app/sources/url/document-url/document-url.component.css ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NvdXJjZXMvdXJsL2RvY3VtZW50LXVybC9kb2N1bWVudC11cmwuY29tcG9uZW50LmNzcyJ9 */");

/***/ }),

/***/ "./src/app/sources/url/document-url/document-url.component.ts":
/*!********************************************************************!*\
  !*** ./src/app/sources/url/document-url/document-url.component.ts ***!
  \********************************************************************/
/*! exports provided: DocumentUrlComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DocumentUrlComponent", function() { return DocumentUrlComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let DocumentUrlComponent = class DocumentUrlComponent {
    constructor() { }
    ngOnInit() {
    }
};
DocumentUrlComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-document-url',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./document-url.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/sources/url/document-url/document-url.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./document-url.component.css */ "./src/app/sources/url/document-url/document-url.component.css")).default]
    })
], DocumentUrlComponent);



/***/ }),

/***/ "./src/app/sources/url/location-document-uri/location-document-uri.component.css":
/*!***************************************************************************************!*\
  !*** ./src/app/sources/url/location-document-uri/location-document-uri.component.css ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NvdXJjZXMvdXJsL2xvY2F0aW9uLWRvY3VtZW50LXVyaS9sb2NhdGlvbi1kb2N1bWVudC11cmkuY29tcG9uZW50LmNzcyJ9 */");

/***/ }),

/***/ "./src/app/sources/url/location-document-uri/location-document-uri.component.ts":
/*!**************************************************************************************!*\
  !*** ./src/app/sources/url/location-document-uri/location-document-uri.component.ts ***!
  \**************************************************************************************/
/*! exports provided: LocationDocumentUriComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LocationDocumentUriComponent", function() { return LocationDocumentUriComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let LocationDocumentUriComponent = class LocationDocumentUriComponent {
    constructor() { }
    ngOnInit() {
    }
};
LocationDocumentUriComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-location-document-uri',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./location-document-uri.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/sources/url/location-document-uri/location-document-uri.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./location-document-uri.component.css */ "./src/app/sources/url/location-document-uri/location-document-uri.component.css")).default]
    })
], LocationDocumentUriComponent);



/***/ }),

/***/ "./src/app/sources/url/location-hash/location-hash.component.css":
/*!***********************************************************************!*\
  !*** ./src/app/sources/url/location-hash/location-hash.component.css ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NvdXJjZXMvdXJsL2xvY2F0aW9uLWhhc2gvbG9jYXRpb24taGFzaC5jb21wb25lbnQuY3NzIn0= */");

/***/ }),

/***/ "./src/app/sources/url/location-hash/location-hash.component.ts":
/*!**********************************************************************!*\
  !*** ./src/app/sources/url/location-hash/location-hash.component.ts ***!
  \**********************************************************************/
/*! exports provided: LocationHashComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LocationHashComponent", function() { return LocationHashComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let LocationHashComponent = class LocationHashComponent {
    constructor() { }
    ngOnInit() {
    }
};
LocationHashComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-location-hash',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./location-hash.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/sources/url/location-hash/location-hash.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./location-hash.component.css */ "./src/app/sources/url/location-hash/location-hash.component.css")).default]
    })
], LocationHashComponent);



/***/ }),

/***/ "./src/app/sources/url/location-host/location-host.component.css":
/*!***********************************************************************!*\
  !*** ./src/app/sources/url/location-host/location-host.component.css ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NvdXJjZXMvdXJsL2xvY2F0aW9uLWhvc3QvbG9jYXRpb24taG9zdC5jb21wb25lbnQuY3NzIn0= */");

/***/ }),

/***/ "./src/app/sources/url/location-host/location-host.component.ts":
/*!**********************************************************************!*\
  !*** ./src/app/sources/url/location-host/location-host.component.ts ***!
  \**********************************************************************/
/*! exports provided: LocationHostComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LocationHostComponent", function() { return LocationHostComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let LocationHostComponent = class LocationHostComponent {
    constructor() { }
    ngOnInit() {
    }
};
LocationHostComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-location-host',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./location-host.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/sources/url/location-host/location-host.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./location-host.component.css */ "./src/app/sources/url/location-host/location-host.component.css")).default]
    })
], LocationHostComponent);



/***/ }),

/***/ "./src/app/sources/url/location-hostname/location-hostname.component.css":
/*!*******************************************************************************!*\
  !*** ./src/app/sources/url/location-hostname/location-hostname.component.css ***!
  \*******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NvdXJjZXMvdXJsL2xvY2F0aW9uLWhvc3RuYW1lL2xvY2F0aW9uLWhvc3RuYW1lLmNvbXBvbmVudC5jc3MifQ== */");

/***/ }),

/***/ "./src/app/sources/url/location-hostname/location-hostname.component.ts":
/*!******************************************************************************!*\
  !*** ./src/app/sources/url/location-hostname/location-hostname.component.ts ***!
  \******************************************************************************/
/*! exports provided: LocationHostnameComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LocationHostnameComponent", function() { return LocationHostnameComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let LocationHostnameComponent = class LocationHostnameComponent {
    constructor() { }
    ngOnInit() {
    }
};
LocationHostnameComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-location-hostname',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./location-hostname.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/sources/url/location-hostname/location-hostname.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./location-hostname.component.css */ "./src/app/sources/url/location-hostname/location-hostname.component.css")).default]
    })
], LocationHostnameComponent);



/***/ }),

/***/ "./src/app/sources/url/location-href/location-href.component.css":
/*!***********************************************************************!*\
  !*** ./src/app/sources/url/location-href/location-href.component.css ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NvdXJjZXMvdXJsL2xvY2F0aW9uLWhyZWYvbG9jYXRpb24taHJlZi5jb21wb25lbnQuY3NzIn0= */");

/***/ }),

/***/ "./src/app/sources/url/location-href/location-href.component.ts":
/*!**********************************************************************!*\
  !*** ./src/app/sources/url/location-href/location-href.component.ts ***!
  \**********************************************************************/
/*! exports provided: LocationHrefComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LocationHrefComponent", function() { return LocationHrefComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let LocationHrefComponent = class LocationHrefComponent {
    constructor() { }
    ngOnInit() {
    }
};
LocationHrefComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-location-href',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./location-href.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/sources/url/location-href/location-href.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./location-href.component.css */ "./src/app/sources/url/location-href/location-href.component.css")).default]
    })
], LocationHrefComponent);



/***/ }),

/***/ "./src/app/sources/url/location-origin/location-origin.component.css":
/*!***************************************************************************!*\
  !*** ./src/app/sources/url/location-origin/location-origin.component.css ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NvdXJjZXMvdXJsL2xvY2F0aW9uLW9yaWdpbi9sb2NhdGlvbi1vcmlnaW4uY29tcG9uZW50LmNzcyJ9 */");

/***/ }),

/***/ "./src/app/sources/url/location-origin/location-origin.component.ts":
/*!**************************************************************************!*\
  !*** ./src/app/sources/url/location-origin/location-origin.component.ts ***!
  \**************************************************************************/
/*! exports provided: LocationOriginComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LocationOriginComponent", function() { return LocationOriginComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let LocationOriginComponent = class LocationOriginComponent {
    constructor() { }
    ngOnInit() {
    }
};
LocationOriginComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-location-origin',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./location-origin.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/sources/url/location-origin/location-origin.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./location-origin.component.css */ "./src/app/sources/url/location-origin/location-origin.component.css")).default]
    })
], LocationOriginComponent);



/***/ }),

/***/ "./src/app/sources/url/location-pathname/location-pathname.component.css":
/*!*******************************************************************************!*\
  !*** ./src/app/sources/url/location-pathname/location-pathname.component.css ***!
  \*******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NvdXJjZXMvdXJsL2xvY2F0aW9uLXBhdGhuYW1lL2xvY2F0aW9uLXBhdGhuYW1lLmNvbXBvbmVudC5jc3MifQ== */");

/***/ }),

/***/ "./src/app/sources/url/location-pathname/location-pathname.component.ts":
/*!******************************************************************************!*\
  !*** ./src/app/sources/url/location-pathname/location-pathname.component.ts ***!
  \******************************************************************************/
/*! exports provided: LocationPathnameComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LocationPathnameComponent", function() { return LocationPathnameComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let LocationPathnameComponent = class LocationPathnameComponent {
    constructor() { }
    ngOnInit() {
    }
};
LocationPathnameComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-location-pathname',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./location-pathname.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/sources/url/location-pathname/location-pathname.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./location-pathname.component.css */ "./src/app/sources/url/location-pathname/location-pathname.component.css")).default]
    })
], LocationPathnameComponent);



/***/ }),

/***/ "./src/app/sources/url/location-search/location-search.component.css":
/*!***************************************************************************!*\
  !*** ./src/app/sources/url/location-search/location-search.component.css ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NvdXJjZXMvdXJsL2xvY2F0aW9uLXNlYXJjaC9sb2NhdGlvbi1zZWFyY2guY29tcG9uZW50LmNzcyJ9 */");

/***/ }),

/***/ "./src/app/sources/url/location-search/location-search.component.ts":
/*!**************************************************************************!*\
  !*** ./src/app/sources/url/location-search/location-search.component.ts ***!
  \**************************************************************************/
/*! exports provided: LocationSearchComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LocationSearchComponent", function() { return LocationSearchComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let LocationSearchComponent = class LocationSearchComponent {
    constructor() { }
    ngOnInit() {
    }
};
LocationSearchComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-location-search',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./location-search.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/sources/url/location-search/location-search.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./location-search.component.css */ "./src/app/sources/url/location-search/location-search.component.css")).default]
    })
], LocationSearchComponent);



/***/ }),

/***/ "./src/app/sources/url/location-url/location-url.component.css":
/*!*********************************************************************!*\
  !*** ./src/app/sources/url/location-url/location-url.component.css ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NvdXJjZXMvdXJsL2xvY2F0aW9uLXVybC9sb2NhdGlvbi11cmwuY29tcG9uZW50LmNzcyJ9 */");

/***/ }),

/***/ "./src/app/sources/url/location-url/location-url.component.ts":
/*!********************************************************************!*\
  !*** ./src/app/sources/url/location-url/location-url.component.ts ***!
  \********************************************************************/
/*! exports provided: LocationUrlComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LocationUrlComponent", function() { return LocationUrlComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let LocationUrlComponent = class LocationUrlComponent {
    constructor() { }
    ngOnInit() {
    }
};
LocationUrlComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-location-url',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./location-url.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/sources/url/location-url/location-url.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./location-url.component.css */ "./src/app/sources/url/location-url/location-url.component.css")).default]
    })
], LocationUrlComponent);



/***/ }),

/***/ "./src/app/sources/url/window-location/window-location.component.css":
/*!***************************************************************************!*\
  !*** ./src/app/sources/url/window-location/window-location.component.css ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NvdXJjZXMvdXJsL3dpbmRvdy1sb2NhdGlvbi93aW5kb3ctbG9jYXRpb24uY29tcG9uZW50LmNzcyJ9 */");

/***/ }),

/***/ "./src/app/sources/url/window-location/window-location.component.ts":
/*!**************************************************************************!*\
  !*** ./src/app/sources/url/window-location/window-location.component.ts ***!
  \**************************************************************************/
/*! exports provided: WindowLocationComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WindowLocationComponent", function() { return WindowLocationComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let WindowLocationComponent = class WindowLocationComponent {
    constructor() { }
    ngOnInit() {
    }
};
WindowLocationComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-window-location',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./window-location.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/sources/url/window-location/window-location.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./window-location.component.css */ "./src/app/sources/url/window-location/window-location.component.css")).default]
    })
], WindowLocationComponent);



/***/ }),

/***/ "./src/app/sources/window-document/document-referrer/document-referrer.component.css":
/*!*******************************************************************************************!*\
  !*** ./src/app/sources/window-document/document-referrer/document-referrer.component.css ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NvdXJjZXMvd2luZG93LWRvY3VtZW50L2RvY3VtZW50LXJlZmVycmVyL2RvY3VtZW50LXJlZmVycmVyLmNvbXBvbmVudC5jc3MifQ== */");

/***/ }),

/***/ "./src/app/sources/window-document/document-referrer/document-referrer.component.ts":
/*!******************************************************************************************!*\
  !*** ./src/app/sources/window-document/document-referrer/document-referrer.component.ts ***!
  \******************************************************************************************/
/*! exports provided: DocumentReferrerComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DocumentReferrerComponent", function() { return DocumentReferrerComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let DocumentReferrerComponent = class DocumentReferrerComponent {
    constructor() { }
    ngOnInit() {
    }
};
DocumentReferrerComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-document-referrer',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./document-referrer.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/sources/window-document/document-referrer/document-referrer.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./document-referrer.component.css */ "./src/app/sources/window-document/document-referrer/document-referrer.component.css")).default]
    })
], DocumentReferrerComponent);



/***/ }),

/***/ "./src/app/sources/window-document/element-value/element-value.component.css":
/*!***********************************************************************************!*\
  !*** ./src/app/sources/window-document/element-value/element-value.component.css ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NvdXJjZXMvd2luZG93LWRvY3VtZW50L2VsZW1lbnQtdmFsdWUvZWxlbWVudC12YWx1ZS5jb21wb25lbnQuY3NzIn0= */");

/***/ }),

/***/ "./src/app/sources/window-document/element-value/element-value.component.ts":
/*!**********************************************************************************!*\
  !*** ./src/app/sources/window-document/element-value/element-value.component.ts ***!
  \**********************************************************************************/
/*! exports provided: ElementValueComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ElementValueComponent", function() { return ElementValueComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let ElementValueComponent = class ElementValueComponent {
    constructor() { }
    ngOnInit() {
    }
};
ElementValueComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-element-value',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./element-value.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/sources/window-document/element-value/element-value.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./element-value.component.css */ "./src/app/sources/window-document/element-value/element-value.component.css")).default]
    })
], ElementValueComponent);



/***/ }),

/***/ "./src/app/sources/window-document/storage-getitem/storage-getitem.component.css":
/*!***************************************************************************************!*\
  !*** ./src/app/sources/window-document/storage-getitem/storage-getitem.component.css ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NvdXJjZXMvd2luZG93LWRvY3VtZW50L3N0b3JhZ2UtZ2V0aXRlbS9zdG9yYWdlLWdldGl0ZW0uY29tcG9uZW50LmNzcyJ9 */");

/***/ }),

/***/ "./src/app/sources/window-document/storage-getitem/storage-getitem.component.ts":
/*!**************************************************************************************!*\
  !*** ./src/app/sources/window-document/storage-getitem/storage-getitem.component.ts ***!
  \**************************************************************************************/
/*! exports provided: StorageGetitemComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StorageGetitemComponent", function() { return StorageGetitemComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let StorageGetitemComponent = class StorageGetitemComponent {
    constructor() { }
    ngOnInit() {
    }
};
StorageGetitemComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-storage-getitem',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./storage-getitem.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/sources/window-document/storage-getitem/storage-getitem.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./storage-getitem.component.css */ "./src/app/sources/window-document/storage-getitem/storage-getitem.component.css")).default]
    })
], StorageGetitemComponent);



/***/ }),

/***/ "./src/app/sources/window-document/window-frame-element/window-frame-element.component.css":
/*!*************************************************************************************************!*\
  !*** ./src/app/sources/window-document/window-frame-element/window-frame-element.component.css ***!
  \*************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NvdXJjZXMvd2luZG93LWRvY3VtZW50L3dpbmRvdy1mcmFtZS1lbGVtZW50L3dpbmRvdy1mcmFtZS1lbGVtZW50LmNvbXBvbmVudC5jc3MifQ== */");

/***/ }),

/***/ "./src/app/sources/window-document/window-frame-element/window-frame-element.component.ts":
/*!************************************************************************************************!*\
  !*** ./src/app/sources/window-document/window-frame-element/window-frame-element.component.ts ***!
  \************************************************************************************************/
/*! exports provided: WindowFrameElementComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WindowFrameElementComponent", function() { return WindowFrameElementComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let WindowFrameElementComponent = class WindowFrameElementComponent {
    constructor() { }
    ngOnInit() {
    }
};
WindowFrameElementComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-window-frame-element',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./window-frame-element.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/sources/window-document/window-frame-element/window-frame-element.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./window-frame-element.component.css */ "./src/app/sources/window-document/window-frame-element/window-frame-element.component.css")).default]
    })
], WindowFrameElementComponent);



/***/ }),

/***/ "./src/app/sources/window-document/window-frames/window-frames.component.css":
/*!***********************************************************************************!*\
  !*** ./src/app/sources/window-document/window-frames/window-frames.component.css ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NvdXJjZXMvd2luZG93LWRvY3VtZW50L3dpbmRvdy1mcmFtZXMvd2luZG93LWZyYW1lcy5jb21wb25lbnQuY3NzIn0= */");

/***/ }),

/***/ "./src/app/sources/window-document/window-frames/window-frames.component.ts":
/*!**********************************************************************************!*\
  !*** ./src/app/sources/window-document/window-frames/window-frames.component.ts ***!
  \**********************************************************************************/
/*! exports provided: WindowFramesComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WindowFramesComponent", function() { return WindowFramesComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let WindowFramesComponent = class WindowFramesComponent {
    constructor() { }
    ngOnInit() {
    }
};
WindowFramesComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-window-frames',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./window-frames.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/sources/window-document/window-frames/window-frames.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./window-frames.component.css */ "./src/app/sources/window-document/window-frames/window-frames.component.css")).default]
    })
], WindowFramesComponent);



/***/ }),

/***/ "./src/app/sources/window-document/window-name/window-name.component.css":
/*!*******************************************************************************!*\
  !*** ./src/app/sources/window-document/window-name/window-name.component.css ***!
  \*******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NvdXJjZXMvd2luZG93LWRvY3VtZW50L3dpbmRvdy1uYW1lL3dpbmRvdy1uYW1lLmNvbXBvbmVudC5jc3MifQ== */");

/***/ }),

/***/ "./src/app/sources/window-document/window-name/window-name.component.ts":
/*!******************************************************************************!*\
  !*** ./src/app/sources/window-document/window-name/window-name.component.ts ***!
  \******************************************************************************/
/*! exports provided: WindowNameComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WindowNameComponent", function() { return WindowNameComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let WindowNameComponent = class WindowNameComponent {
    constructor() { }
    ngOnInit() {
    }
};
WindowNameComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-window-name',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./window-name.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/sources/window-document/window-name/window-name.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./window-name.component.css */ "./src/app/sources/window-document/window-name/window-name.component.css")).default]
    })
], WindowNameComponent);



/***/ }),

/***/ "./src/app/sources/window-document/window-prompt/window-prompt.component.css":
/*!***********************************************************************************!*\
  !*** ./src/app/sources/window-document/window-prompt/window-prompt.component.css ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NvdXJjZXMvd2luZG93LWRvY3VtZW50L3dpbmRvdy1wcm9tcHQvd2luZG93LXByb21wdC5jb21wb25lbnQuY3NzIn0= */");

/***/ }),

/***/ "./src/app/sources/window-document/window-prompt/window-prompt.component.ts":
/*!**********************************************************************************!*\
  !*** ./src/app/sources/window-document/window-prompt/window-prompt.component.ts ***!
  \**********************************************************************************/
/*! exports provided: WindowPromptComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WindowPromptComponent", function() { return WindowPromptComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let WindowPromptComponent = class WindowPromptComponent {
    constructor() { }
    ngOnInit() {
    }
};
WindowPromptComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-window-prompt',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./window-prompt.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/sources/window-document/window-prompt/window-prompt.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./window-prompt.component.css */ "./src/app/sources/window-document/window-prompt/window-prompt.component.css")).default]
    })
], WindowPromptComponent);



/***/ }),

/***/ "./src/app/templates/rule/rule.component.css":
/*!***************************************************!*\
  !*** ./src/app/templates/rule/rule.component.css ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3RlbXBsYXRlcy9ydWxlL3J1bGUuY29tcG9uZW50LmNzcyJ9 */");

/***/ }),

/***/ "./src/app/templates/rule/rule.component.ts":
/*!**************************************************!*\
  !*** ./src/app/templates/rule/rule.component.ts ***!
  \**************************************************/
/*! exports provided: RuleComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RuleComponent", function() { return RuleComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let RuleComponent = class RuleComponent {
    constructor() { }
    ngOnInit() {
    }
};
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], RuleComponent.prototype, "rule", void 0);
RuleComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-rule',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./rule.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/templates/rule/rule.component.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./rule.component.css */ "./src/app/templates/rule/rule.component.css")).default]
    })
], RuleComponent);



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

const environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm2015/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");





if (_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_2__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_3__["AppModule"])
    .catch(err => console.error(err));


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! /Users/nickjantz/repos/javascript-test-bench/angular/angular8/src/main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main-es2015.js.map